"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes unit tests for verifying that SOPConnection runs correctly.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

import unittest

from sop.calibration import SOPConnection, Connections

class SOPConnectionTester(unittest.TestCase):
    """
    SOPConnectionTester

    Description:
    A test class for verifying the the units within SOPConnection execute
    correctly.
    """

    def test_init(self):
        """
        test_init

        Description:
        Tests whether an instance of SOPConnection can be created.
        """

        # Try to initialise an instance of SOPConnection
        try:
            connt = Connections.WIFI
            conn = SOPConnection(connt, "192.168.0.1", "8196",
                                                    "192.168.0.2", "8197")
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(cfg))
            self.fail(err)


    def test_to_dict(self):
        """
        test_to_dict

        Description:
        Tests whether the SOPConnection instance can be converted to a
        dictionary.
        """

        # Initialise an SOPConnection instance
        connt = Connections.WIFI
        conn = SOPConnection(connt, "192.168.0.1", "8196",
                                                "192.168.0.2", "8197")

        # Try to convert the instance to a dictionary
        try:
            conn_dict = conn.to_dict()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(cfg))
            self.fail(err)

        # Ensure the values are correct
        self.assertEqual(conn_dict["CONNECTION_TYPE"], 0)
        self.assertEqual(conn_dict["LEFT_IP"], "192.168.0.1")
        self.assertEqual(conn_dict["LEFT_PORT"], "8196")
        self.assertEqual(conn_dict["RIGHT_IP"], "192.168.0.2")
        self.assertEqual(conn_dict["RIGHT_PORT"], "8197")

        # Initialise an SOPConnection instance
        connt = Connections.USB
        conn = SOPConnection(connt, None, "0", None, "1")

        # Try to convert the instance to a dictionary
        try:
            conn_dict = conn.to_dict()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(cfg))
            self.fail(err)

        # Ensure the values are correct
        self.assertEqual(conn_dict["CONNECTION_TYPE"], 1)
        self.assertEqual(conn_dict["LEFT_IP"], None)
        self.assertEqual(conn_dict["LEFT_PORT"], "0")
        self.assertEqual(conn_dict["RIGHT_IP"], None)
        self.assertEqual(conn_dict["RIGHT_PORT"], "1")















































