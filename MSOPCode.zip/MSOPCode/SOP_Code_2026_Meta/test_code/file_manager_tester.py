"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes unit tests for verifying that FileManager runs correctly.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

import unittest

from sop.utils import FileManager


class FileManagerTester(unittest.TestCase):
    """
    FileManagerTester

    Description:
    Tests the various static functions in the FileManager static class.
    """

    def test_get_sop_dir(self):
        """
        test_get_sop_dir

        Description:
        Tests whether the SOP directory can be returned correctly.
        """

        # Try to get the SOP directory
        try:
            sop_dir = FileManager.get_sop_dir()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(sop_dir, "/Users/kylenewman/Documents/"\
                            "OncoRes/NCORR_Project/StereoOpticalPalpation/")


    def test_get_data_dir(self):
        """
        test_get_data_dir

        Description:
        Tests whether the SOP data directory can be returned correctly.
        """

        # Try to get the SOP data directory
        try:
            data_dir = FileManager.get_data_dir()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(data_dir, "/Users/kylenewman/Documents/OncoRes/"\
                            "NCORR_Project/StereoOpticalPalpation/SOP_Data/")


    def test_get_probe_dir(self):
        """
        test_get_probe_dir

        Description:
        Tests whether the probe directory can be found correctly.
        """

        # Try to get the probe directory
        try:
            probe_dir = FileManager.get_probe_dir(0)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(probe_dir, "/Users/kylenewman/Documents/OncoRes/"\
                    "NCORR_Project/StereoOpticalPalpation/SOP_Data/Probe_0/")


    def test_get_scans_dir(self):
        """
        test_get_probe_dir

        Description:
        Tests whether the probe's scans directory can be found correctly.
        """

        # Try to get the probe's scans directory
        try:
            scans_dir = FileManager.get_scans_dir(0)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(scans_dir, "/Users/kylenewman/Documents/OncoRes/"\
            "NCORR_Project/StereoOpticalPalpation/SOP_Data/Probe_0/Scans/")


    def test_left_dir(self):
        """
        test_left_dir

        Description:
        Tests whether the left directory can be found correctly.
        """

        # Try to get the left directory
        try:
            left_dir = FileManager.get_left_dir(0)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(left_dir, "/Users/kylenewman/Documents/OncoRes/"\
                        "NCORR_Project/StereoOpticalPalpation/SOP_Data/"\
                        "Probe_0/Left/")


    def test_right_dir(self):
        """
        test_right_dir

        Description:
        Tests whether the right directory can be found correctly.
        """

        # Try to get the right directory
        try:
            right_dir = FileManager.get_right_dir(0)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(right_dir, "/Users/kylenewman/Documents/OncoRes/"\
                        "NCORR_Project/StereoOpticalPalpation/SOP_Data/"\
                        "Probe_0/Right/")


    def test_get_disp_dist_dir(self):
        """
        test_get_disp_dist_dir

        Description:
        Tests whether the disparity to displacement directory can be found
        correctly.
        """

        # Try to get the disparity to displacement directory
        try:
            dirr = FileManager.get_disp_dist_dir(0)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the directory is correct
        self.assertEqual(dirr, "/Users/kylenewman/Documents/OncoRes/"\
                        "NCORR_Project/StereoOpticalPalpation/SOP_Data/"\
                        "Probe_0/Disparity_Displacement/")


    def test_get_slash(self):
        """
        test_get_slash

        Description:
        Tests whether the correct slash character is returned.
        """

        # Try to get the slash character
        try:
            slash = FileManager.get_slash()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the slash character is correct
        self.assertEqual(slash, "/")




































