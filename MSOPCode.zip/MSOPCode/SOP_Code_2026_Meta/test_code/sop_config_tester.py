"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes unit tests for verifying that SOPConfig runs correctly.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

import unittest
import os
import json

from sop.calibration import SOPConfig, SOPConnection, Connections
from sop.utils import FileManager


class SOPConfigTester(unittest.TestCase):
    """
    SOPConfigTester

    Description:
    A unit test class for the SOPConfig class.
    """

    def test_init(self):
        """
        test_init

        Description:
        Ensure that an instance of 'SOPConfig' can be initialised.
        """

        # Define the inputs for initialisation
        probe_id = 16
        idx = __file__.rfind("/") + 1
        dirr = __file__[:idx]
        with open(dirr + "Config.json", "r") as fp:
            cfg = json.load(fp)

        # Try to initialise an instance of SOPConfig with a cfg file
        try:
            cfg = SOPConfig(probe_id, cfg)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Try to initialise an instance of SOPConfig without a cfg file
        try:
            sop_cfg = SOPConfig(probe_id, None)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_res(self):
        """
        test_set_res

        Description:
        Tests whether the resolution of the system can be set.
        """

        # Initialise a SOPConfig instance
        sop_cfg = SOPConfig(16, None)

        # Try to set the resolution
        try:
            sop_cfg.set_res((1280, 720))
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_connection(self):
        """
        test_set_connection

        Description:
        Tests whetehr the connection details of the probe can be set.
        """

        # Initialise a SOPConfig and SOPConnection instance
        sop_cfg = SOPConfig(16, None)
        connection = SOPConnection(Connections.USB, lport = "0", rport = "1")

        # Try to set the connection details
        try:
            sop_cfg.set_connection(connection)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_calib_size(self):
        """
        test_set_calib_size

        Description:
        Tests whether the calibration pattern size can be set.
        """

        # Initialise a SOPConfig and SOPConnection instance
        sop_cfg = SOPConfig(16, None)

        # Try to set the calibration pattern size
        try:
            sop_cfg.set_calib_size((6, 9))
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_sqr_size(self):
        """
        test_set_sqr_size

        Description:
        Tests whether the calibration pattern square size can be set.
        """

        # Initialise a SOPConfig and SOPConnection instance
        sop_cfg = SOPConfig(16, None)

        # Try to set the calibration pattern size
        try:
            sop_cfg.set_sqr_size(2.3)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))


    def test_to_dict(self):
        """
        test_to_dict

        Description:
        Tests whether a SOPConfig instance can be converted to a dictionary.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to convert the configuration to a dictionary
        try:
            cfg_dict = cfg.to_dict()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Define the rectification corners
        corns_im = [["TLxy"], ["TRxy"], ["BRxy"], ["BLxy"]]
        corns_ww = [["TLxyz"], ["TRxyz"], ["BRxyz"], ["BLxyz"]]
        rect_corns = {"LEFT_CORNERS": corns_im, "RIGHT_CORNERS": corns_im,
                                                "WORLD_CORNERS": corns_ww}

        # Define the expected ROI
        roi = {}
        roi.update({"top_edge": 250})
        roi.update({"bottom_edge": 658})
        roi.update({"left_edge": 500})
        roi.update({"right_edge": 1004})

        # Check the returned dictionary is correct
        self.assertEqual(cfg_dict["PROBE_ID"], 0)
        self.assertEqual(cfg_dict["RESOLUTION"], (1280, 720))
        self.assertEqual(cfg_dict["CONNECTION_DETAILS"], conn.to_dict())
        self.assertEqual(cfg_dict["CALIBRATION_SIZE"], (6, 9))
        self.assertEqual(cfg_dict["SOFTWARE_VERSION"], None)
        self.assertEqual(cfg_dict["CALIBRATION_PARAMETERS"], None)
        self.assertEqual(cfg_dict["DISPLACEMENT_MODEL"], None)
        self.assertEqual(cfg_dict["OFFSET_VALUES"], None)
        self.assertEqual(cfg_dict["SEARCH_RANGE"], None)
        self.assertEqual(cfg_dict["ROI"], roi)
        self.assertEqual(cfg_dict["COMMENTS"], None)
        self.assertEqual(cfg_dict["SQUARE_SIZE"], None)
        self.assertEqual(cfg_dict["RECTIFICATION_CORNERS"], rect_corns)


    def test_set_calib_params(self):
        """
        test_set_calib_params

        Description:
        Tests whether SOPConfig can correctly set the calibration parameters.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Define the "calibration parameters"
        calib_params = {}
        calib_params.update({"cmatrixL": 0})
        calib_params.update({"dcoefsL": 0})
        calib_params.update({"cmatrixR": 0})
        calib_params.update({"dcoefsR": 0})
        calib_params.update({"R_L": 0})
        calib_params.update({"P_L": 0})
        calib_params.update({"R_R": 0})
        calib_params.update({"P_R": 0})

        # Try to set the calibration parameters
        try:
            cfg.set_calib_params(calib_params)
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_version(self):
        """
        test_set_version

        Description:
        Tests whether the version of the software can be set correctly.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to set the version
        try:
            cfg.set_version("dhasidhno213809")
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_displ_model(self):
        """
        test_set_displ_model

        Description:
        Tests whether the displacement model can be set.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to set the displacement model
        try:
            cfg.set_displ_model([-0.039, 32.79])
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_offset(self):
        """
        test_set_offset

        Description:
        Tests whether the offset values can be set correctly.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to set the displacement model
        try:
            cfg.set_offset([10, -440])
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_set_srange(self):
        """
        test_set_srange

        Description:
        Tests whether the search range can be set correctly.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to set the displacement model
        try:
            cfg.set_srange([[-10, 10], [-30, 30]])
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)


    def test_save(self):
        """
        test_save

        Description:
        Tests whether the SOP configuration can be saved to a JSON file.
        """

        # Initialise an SOPConfig instance
        probe_id = 0
        res = (1280, 720)
        conn = SOPConnection(Connections.USB, None, "0", None, "1")
        calib_size = (6, 9)
        cfg = SOPConfig(probe_id, None)
        cfg.set_res(res)
        cfg.set_connection(conn)
        cfg.set_calib_size(calib_size)

        # Try to save the configuration to a JSON file
        try:
            cfg.save()
        except Exception as excp:
            # Indicate than initialisation was not successful
            err = "Exception thrown:\n{}".format(str(excp))
            self.fail(err)

        # Check the file exists
        ddir = FileManager.get_data_dir()
        pdir = ddir + "Probe_{}/".format(probe_id)
        pfile = pdir + "Config.json"
        self.assertTrue(os.path.isfile(pfile))

        # Remove the configuration file and the probe zero directory
        os.remove(pfile)
        os.rmdir(pdir)




































