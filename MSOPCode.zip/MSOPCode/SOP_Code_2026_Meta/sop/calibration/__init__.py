"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Setup calibration as an importable sub-module.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

# Import necesary classes to shorten referencing from outside the package
from .calibration import StereoCalibrator
from .sop_config import SOPConfig, SOPConnection, Connections