"""
Author: Kyle Robert Newman
Date: 7 February 2020
Company: BRITElab & OncoRes

Program Description:
This program contains a StereoCalibrator class which can be used to calibrate
a stereo camera system. This class provides additional functionality to help
the user identify why calibration may not be working and how to resolve issues
faced.

Version History
V1 -> 7 February 2020
Initial program implementation. In this implementation of StereoCalibrator it
allows a stereo probe system to be calibrated and provides useful feedback why
the calibration may not be working and how to resolve this. However, in this
implementation there is no support for automated calibration image taking.
Instead the take_pic.py program must be used for this and then the respective
files copied into the probe's "Left" and "Right" data files.
"""

import cv2
import json
import glob

import numpy as np
import matplotlib.pyplot as plt

from mpl_toolkits.mplot3d import axes3d, Axes3D
from scipy.spatial.transform import Rotation
from argparse import ArgumentParser
from pathlib import Path
from ..utils import FileManager
from .sop_config import Connections, SOPConnection, SOPConfig


class StereoCalibrator:
    """
    StereoCalibrator

    Description:
    A class used to step the user through the stereo camera calibration
    process. When the correct conditions are met, this class will also save
    the calibration parameters associated with the stereo camera system to a
    JSON file within its data directory.
    """

    def __init__(self, probe_id: int, show_last: bool, calib_disp: bool):
        """
        __init__

        Description:
        Initializes the StereoCalibrator object so that it is ready to
        calibrate the stereo cameras.

        Inputs:
            - probe_id : int
                An integer identifier given to the stereo-probe.
            - show_last : bool
                A boolean value indicating whether only the last image pair's
                corners should be shown.
            - calib_disp : bool
                A boolean value indicating whether this class should display
                any images or plots.
        """

        # Ensure that the input types are correct
        if(not isinstance(probe_id, int)):
            err = "'probe_id' should be an int."
            raise TypeError(err)

        if(not isinstance(show_last, bool)):
            err = "'show_last' should be a bool."
            raise TypeError(err)

        if(not isinstance(calib_disp, bool)):
            err = "'calib_disp' should be a bool."
            raise TypeError(err)

        # Ensure that the input values are correct
        if(probe_id < 0):
            err = "'probe_id' should be greater than or equal to zero."
            raise ValueError(err)

        # Save the inputs as private fields
        self.__probe_id = probe_id
        self.__show_last = show_last
        self.__calib_disp = calib_disp

        # Find the directories the calibration images can be found in
        self.__probe_dir = FileManager.get_data_dir()
        self.__left_calib_dir = FileManager.get_left_dir(probe_id) + "*.jpg"
        self.__right_calib_dir = FileManager.get_right_dir(probe_id) + "*.jpg"

        # Find the files in each directory and sort them alphabetically
        self.__left_files = glob.glob(self.__left_calib_dir)
        self.__left_files.sort()
        self.__right_files = glob.glob(self.__right_calib_dir)
        self.__right_files.sort()

        self.__only_show_corners = False # got rid of checks for number of images and matching left and right images, since we are injecting corner coordinates directly now


    def __get_real_coords(
        self,
        num_corners: tuple = (6, 9),
        sqr_size: np.float64 = 0.8
        ) -> np.ndarray:
        """
        __get_real_coords

        Description:
        A private method which returns the "real world" three dimensional
        coordinates of a chessboard pattern with the specified dimensions.

        Inputs:
            - num_corners : tuple
                The number of corners in the calibration pattern. This should
                contain two integer elements. The first element specifies the
                number of internal corner rows in the chessboard pattern. The
                second element specifies the number of internal corner columns
                in the chessboard pattern.
            - sqr_size : np.float64
                The width of each square in the chessboard. This should be
                meassured in millimeters.

        Outputs:
            - obj_points : np.ndarray
                The real world coordinates where the chessboard corners can be
                found. This should have a shape of (rows*columns, 3). Each
                element of this array is of type np.float64.
        """

        # Holds the real world coordinates
        obj_points = np.zeros((num_corners[0] * num_corners[1], 3),
                                                        dtype = np.float32)

        # Define the real world locations
        for yy in range(num_corners[1]):
            for xx in range(num_corners[0]):
                obj_points[yy * num_corners[0] + xx, 0] = sqr_size * xx
                obj_points[yy * num_corners[0] + xx, 1] = sqr_size * yy
                obj_points[yy * num_corners[0] + xx, 2] = 0.0

        return obj_points


    def __calibrate_cam(
        self,
        res: tuple,
        calib_path,
        num_corners: tuple = (6, 9),
        sqr_size: np.float64 = 0.8):
        """
        __calibrate_cam

        Description:
        A private method that determines intrinsic parameters of a camera
        based off some calibration images.

        Inputs:
            - fnames : list
                A list of strings, with each string being a path to a file
                which contains a calibration image for the camera.
            - calib_path : string
                path to load corners from
            - num_corners : tuple
                A tuple containing two integer values. The first value should
                represent the number of x-axis corners in the calibration
                chessboard and the second value should represent the number of
                y-axis corners in the calibration chessboard. The default is
                (6, 9).
            - sqr_size : np.float64
                A floating point value represented the real world size of the
                squares in the chessboard. Since this is unitless, assume that
                it is in mm.

        Outputs:
            - rval : np.float64
                The reprojection error of the calibrated camera.
            - real_points : list
                A list of elments were each element contains the three-
                dimensional location of a chessboard corner in the world
                coordinate system. By default, these points are measured in
                centimeters.
            - image_points : list
                A list of elements were each element contains the two-
                dimensional pixel location of a chessboard in an image.
            - cmatrix : np.ndarray
                A multi-dimensional np.ndarray which contains the camera
                matrix of the camera.
            - dcoefs : np.ndarray
                A multi-dimensional np.ndarray which contains the distortion
                coefficients of the camera. This program assumes that five
                distortion coefficients should be used; three radial and two
                tangential.
        """

        # Ensure the inputs are correct
        #if(not isinstance(fnames, list) or not isinstance(fnames[0], str)):
        #    err = "'fnames' should be a list of strings."
        #    raise TypeError(err)

        if(not isinstance(num_corners, tuple) or len(num_corners) != 2):
            err = "'num_corners' should be a tuple containing two elements."
            raise TypeError(err)

        if(not isinstance(num_corners[0], int)):
            err = "The values in 'num_corners' should be integers."
            raise TypeError(err)

        if(num_corners[0] <= 0 or num_corners[1] <= 0):
            err = "'num_corners' should contain only numbers greater than"\
                    " zero."
            raise ValueError(err)

        if(not isinstance(sqr_size, float)):
            err = "'sqr_size' should be a floating point value."
            raise TypeError(err)

        if(sqr_size < 0.00000001):
            err = "'sqr_size' should be greater than zero."
            raise ValueError(err)

        # Find the real world coordinates of the corners
        world_corners = self.__get_real_coords(num_corners, sqr_size)

        # Lists to hold the real world points and image points for each image
        real_points = []
        image_points = []

        # Holds the gray scale image
        gray_im = None
        #print(calib_path)
        corners = np.load(calib_path,allow_pickle=True)
        #print(corners[0])
        #print(res)

        # Work through each image and find all chessboard corners
        for image_corners in corners:
            # Read in the current image
            #im = cv2.imread(filename)

            # Convert to a gray scale image to find the chessboard corners
            #gray_im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

            # Find the chessboard corners
            #rval, image_corners = cv2.findChessboardCorners(gray_im,
            #                                            num_corners, None)

            # Make sure that the corners are actually detected
            #if(not rval):
            #    err = "Could not detect corners on:\n{}".format(filename)
            #    raise RuntimeError(err)

            # Append new points for the new observed image
            real_points.append(world_corners.copy())
            image_points.append(image_corners.copy())

            #if(not self.__show_last and self.__calib_disp):
            #    im1 = cv2.drawChessboardCorners(im, num_corners,
            #                                            image_corners, rval)
            #    plt.imshow(im1)
            #    plt.show()
                # cv2.namedWindow(filename, cv2.WINDOW_NORMAL)
                # cv2.moveWindow(filename, 40, 30)
                # cv2.resizeWindow(filename, (960, 540))
                # cv2.imshow(filename, im)
                # cv2.waitKey(4000)
                # cv2.destroyAllWindows()
            #elif(filename == fnames[-1] and self.__calib_disp):
            #    im1 = cv2.drawChessboardCorners(im, num_corners,
            #                                            image_corners, rval)
            #    plt.imshow(im1)
            #    plt.show()
                # cv2.namedWindow(filename, cv2.WINDOW_NORMAL)
                # cv2.moveWindow(filename, 40, 30)
                # cv2.resizeWindow(filename, (960, 540))
                # cv2.imshow(filename, im)
                # cv2.waitKey(4000)
                # cv2.destroyAllWindows()
        
        # Calibrate the camera
        rval, cmatrix, dcoefs, rot_vecs, trans_vecs = cv2.calibrateCamera(
                real_points, image_points, (res[1],res[0]), None, None)
        

        return rval, real_points, image_points, cmatrix, dcoefs


    def __check_valid_values(
        self,
        im: np.ndarray,
        reproL: np.float32,
        reproR: np.float32,
        cmatrixL: np.ndarray,
        dcoefsL: np.ndarray,
        cmatrixR: np.ndarray,
        dcoefsR: np.ndarray):
        """
        __check_valid_values

        Description:
        A private method used to check whether the calibration parameters
        returned are reasonable. In the event that the calibration parameters
        are unreasonable this method will raise a warning and inform the user
        of how to resolve this issue.

        Inputs:
            - im : np.ndarray
                An image used for camera calibration. This assumes that the
                resolution of all calibration images are the same.
            - reproL : np.float32
                The reprojection error of the left camera.
            - reproR : np.float32
                The reprojection error of the right camera.
            - cmatrixL : np.ndarray
                A multi-dimensional np.ndarray which contains the camera
                matrix of the left camera.
            - dcoefsL : np.ndarray
                A multi-dimensional np.ndarray which contains the distortion
                coefficients of the left camera. This program assumes that
                five distortion coefficients should be used; three radial and
                two tangential.
            - cmatrixR : np.ndarray
                A multi-dimensional np.ndarray which contains the camera
                matrix of the right camera.
            - dcoefsR : np.ndarray
                A multi-dimensional np.ndarray which contains the distortion
                coefficients of the right camera. This program assumes that
                five distortion coefficients should be used; three radial and
                two tangential.
        """

        # Check whether reprojection errors are reasonable
        # if(1.1 < reproL):
        #     err = "Left camera reprojection error high. Take more images."
        #     raise RuntimeError(err)

        # if(1.1 < reproR):
        #     err = "Right camera reprojection error high. Take more images."
        #     raise RuntimeError(err)

        # Check whether individual focal points are inaccurate
        if((cmatrixL[0, 0] < (cmatrixL[1, 1] * 0.9)) or
                            ((cmatrixL[1, 1] * 1.1) < cmatrixL[0, 0])):
            err = "Left camera does not have fx ~ fy. Take more images."
            raise RuntimeError(err)

        if((cmatrixR[0, 0] < (cmatrixR[1, 1] * 0.9)) or
                            ((cmatrixR[1, 1] * 1.1) < cmatrixR[0, 0])):
            err = "Right camera does not have fx ~ fy. Take more images."
            raise RuntimeError(err)

        # Check if the two cameras focal points are similar
        if((cmatrixR[0, 0] < (cmatrixL[0, 0] * 0.7)) or
                            ((cmatrixL[0, 0] * 1.3) < cmatrixR[0, 0])):
            err = "Left and right cameras do not satisfy fx_L ~ fx_R. Take"\
                    " more images."
            raise RuntimeError(err)

        if((cmatrixR[1, 1] < (cmatrixL[1, 1] * 0.7)) or
                            ((cmatrixL[1, 1] * 1.3) < cmatrixR[1, 1])):
            err = "Left and right cameras do not satisfy fy_L ~ fy_R. Take"\
                    " more images."
            raise RuntimeError(err)

        # Check if Cx and Cy are near the centre of the image plane
        if(cmatrixL[0, 2] < (0.2 * im.shape[1]) or
                                (0.8 * im.shape[1]) < cmatrixL[0, 2]):
            err = "Cx in left image is not near the image centre."
            raise RuntimeError(err)

        if(cmatrixL[1, 2] < (0.2 * im.shape[0]) or
                                (0.8 * im.shape[0]) < cmatrixL[1, 2]):
            err = "Cy in left image is not near the image centre."
            raise RuntimeError(err)

        if(cmatrixR[0, 2] < (0.2 * im.shape[1]) or
                                (0.8 * im.shape[1]) < cmatrixR[0, 2]):
            err = "Cx in right image is not near the image centre."
            raise RuntimeError(err)

        if(cmatrixR[1, 2] < (0.2 * im.shape[0]) or
                                (0.8 * im.shape[0]) < cmatrixR[1, 2]):
            err = "Cy in right image is not near the image centre."
            raise RuntimeError(err)

        # Check if Cx and Cy have similar values for the two cameras
        if((cmatrixR[0, 2] < (cmatrixL[0, 2] * 0.5)) or
                            ((cmatrixL[0, 2] * 1.5) < cmatrixR[0, 2])):
            err = "Left and right cameras do not satisfy Cx_L ~ Cx_R. Take"\
                    " more images."
            raise RuntimeError(err)

        if((cmatrixR[1, 2] < (cmatrixL[1, 2] * 0.5)) or
                            ((cmatrixL[1, 2] * 1.5) < cmatrixR[1, 2])):
            err = "Left and right cameras do not satisfy Cy_L ~ Cy_R. Take"\
                    " more images."
            raise RuntimeError(err)


    def calibrate(
        self,
        res: tuple,
        calib_path_imL,
        calib_path_imR,
        calib_path_L,
        calib_path_R,
        calib_filedir,
        calib_path_RL,
        calib_path_RR,
        val_num,
        num_corners: tuple = (9, 10),
        sqr_size: np.float32 = 3.0
        ) -> (np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict):
        """
        calibrate

        Description:
        This method is composed of three distinct stages:
            1) Calibrate the left and right cameras individually.
            2) Calibrate the cameras as a pair.
            3) Find R_L, P_L, R_R and P_R (camera rotations and new camera
               matrices).
        With the final output being the rectification maps.

        Inputs:
            - num_corners : tuple
                The number of corners in the caibration pattern. This should
                contain two integer values. The first value should represent
                the number of x-axis corners in the calibration chessboard and
                the second value should represent the number of y-axis corners
                in the calibration chessboard. The default is (6, 9).
            - sqr_size : np.float32
                Real world size of the squares in the chessboard. This is a
                unitless value, however for consistency assume that this is
                defined in millimeters. The default value is 0.3.

        Outputs:
            - lmap1 : np.ndarray
                The first rectification map for the left camera.
            - lmap2 : np.ndarray
                The second rectification map for the left camera.
            - rmap1 : np.ndarray
                The first rectification map for the right camera.
            - rmap2 : np.ndarray
                The second rectification map for the right camera.
            - calib_params : dict
                The calibration parameters required to calculate the
                rectification maps. The structure of this dictionary is:
                   {
                        "cmatrixL": val,
                        "dcoefsL": val,
                        "cmatrixR": val,
                        "dcoefsR": val,
                        "R_L": val,
                        "P_L": val,
                        "R_R": val,
                        "P_R": val
                    }
        """

        # Ensure the inputs are correct
        if(not isinstance(num_corners, tuple) or len(num_corners) != 2):
            err = "'num_corners' should be a tuple containing two elements."
            raise TypeError(err)

        if(not isinstance(num_corners[0], int)):
            err = "The values in 'num_corners' should be integers."
            raise TypeError(err)

        if(num_corners[0] <= 0 or num_corners[1] <= 0):
            err = "'num_corners' should contain only numbers greater than"\
                    " zero."
            raise ValueError(err)

        if(not isinstance(sqr_size, float)):
            err = "'sqr_size' should be a floating point value."
            raise TypeError(err)

        if(sqr_size < 0.00000001):
            err = "'sqr_size' should be greater than zero."
            raise ValueError(err)


        # ----------------- CALIBRATE CAMERAS INDIVIDUALLY ----------------- #
        # Calibrate the left and right hand cameras
        rvalL, real_pointsL, image_pointsL, cmatrixL, dcoefsL = \
            self.__calibrate_cam(res,calib_path_L, num_corners, sqr_size)
        rvalR, real_pointsR, image_pointsR, cmatrixR, dcoefsR = \
            self.__calibrate_cam(res,calib_path_R, num_corners, sqr_size)

        # Check that the camera calibration is reasonable
        print("\n# --------- CHECK INDIVIDUAL CAMERA CALIBRATION --------- #")
        print("Left Camera Reprojection Error:\t{}".format(rvalL))
        print("Left Camera Matrix:\n{}".format(cmatrixL))
        print("Left Camera Distortion Coefficients:\n{}".format(dcoefsL))

        print("\nRight Camera Reprojection Error:\t{}".format(rvalR))
        print("Right Camera Matrix:\n{}".format(cmatrixR))
        print("Right Camera Distortion Coefficients:\n{}".format(dcoefsR))
        print("# ------------------------------------------------------- #")

        # Read in first left and right images
        #imL = cv2.imread(self.__left_files[0])
        #imR = cv2.imread(self.__right_files[0])
        imL = np.load(calib_path_imL)
        imR = np.load(calib_path_imR)

        # Check whether the calibration parameters are reasonable
        self.__check_valid_values(imL, rvalL, rvalR, cmatrixL, dcoefsL,
                                                            cmatrixR, dcoefsR)

        # Show images being undistorted
        undist_imL = cv2.undistort(imL, cmatrixL, dcoefsL, None)
        undist_imR = cv2.undistort(imR, cmatrixR, dcoefsR, None)

        if(self.__calib_disp):
            plt.figure(1)
            plt.imshow(undist_imL)
            plt.title("Undistorted Left Image")

            plt.figure(2)
            plt.imshow(undist_imR)
            plt.title("Undistorted Right Image")
            plt.show()
        # ------------------------------------------------------------------ #


        # ------------------ CALIBRATE STEREO CAMERA PAIR ------------------ #
        # Calibrate the stereo system
        rval, cmatrixL, dcoefsL, cmatrixR, dcoefsR, R, T, E, F = \
            cv2.stereoCalibrate(real_pointsL, image_pointsL, image_pointsR,
                                cmatrixL, dcoefsL, cmatrixR, dcoefsR, 
                                (imL.shape[1], imL.shape[0]),
                                flags = cv2.CALIB_FIX_INTRINSIC)

        print("\n\n# ---------- CHECK STEREO CAMERA CALIBRATION ---------- #")
        print("Reprojection Error:\t{}".format(rval))

        print("\nLeft Camera Matrix:\n{}".format(cmatrixL))
        print("Left Camera Distortion Coefficients:\n{}".format(dcoefsL))

        print("\nRight Camera Matrix:\n{}".format(cmatrixR))
        print("Right Camera Distortion Coefficients:\n{}".format(dcoefsR))

        print("\nRelative Rotation:\n{}".format(R))
        print("Relative Translation:\n{}".format(T))
        print("# ----------------------------------------------------- #")

        # Check whether the calibration parameters are reasonable
        self.__check_valid_values(imL, rvalL, rvalR, cmatrixL, dcoefsL,
                                                            cmatrixR, dcoefsR)

        # Check whether the rotation matrix is close to an identity matrix                      # NORMALLY THESE WOULD BE ON !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        #if(0.02 < np.fabs(R[0, 0] - 1.0) or 0.02 < np.fabs(R[1, 1] - 1.0) or
        #                                    0.02 < np.fabs(R[2, 2] - 1.0)):
        #    err = "'R' should be close to an identiy matrix. Take more"\
        #            " images, and try tilting the pattern."
        #    raise RuntimeError(err)

        #if(0.05 < np.fabs(R[0, 1]) or 0.05 < np.fabs(R[0, 2]) or
        #                                        0.05 < np.fabs(R[1, 2])):
        #    err = "'R' should be close to an identiy matrix. Take more"\
        #            " images, and try tilted images."
        #    raise RuntimeError(err)

        #if(0.05 < np.fabs(R[1, 0]) or 0.05 < np.fabs(R[2, 0]) or
        #                                        0.05 < np.fabs(R[2, 1])):
        #    err = "'R' should be close to an identiy matrix. Take more"\
        #            " images, and try tilted images."
        #    raise RuntimeError(err)

        # Check whether the translation vector is reasonable
        if(np.fabs(T[0, 0]) < (5 * np.fabs(T[1, 0])) or
                            np.fabs(T[0, 0]) < (5 * np.fabs(T[2, 0]))):
            err = "The translation in the x-direction should be much larger"\
                    " than in the y or z directions. Take more tilted images."
            raise RuntimeError(err)
        # ------------------------------------------------------------------ #


        # -------------- FIND CAMERA RECTIFICATION PARAMETERS -------------- #
        # Find R_L, R_R, P_L and P_R
        R_L = np.zeros((3, 3), dtype = float)   # Camera rotation left
        R_R = np.zeros((3, 3), dtype = float)	# Camera rotation right
        P_L = np.zeros((3, 4), dtype = float)   # New camera matrix - left
        P_R = np.zeros((3, 4), dtype = float)	# New camera matrix - right
        cv2.stereoRectify(cmatrixL, dcoefsL, cmatrixR, dcoefsR,
                            (imL.shape[1], imL.shape[0]), R, T, R_L, R_R,
                            P_L, P_R, flags = cv2.CALIB_ZERO_DISPARITY)

        print("\n\n# ------- CHECK CAMERA RECTIFICATION PARAMETER -------- #")
        print("Rotate Left Camera By:\n{}".format(R_L))
        print("New Left Camera Matrix:\n{}".format(P_L))

        print("\nRotate Right Camera By:\n{}".format(R_R))
        print("New Right Camera Matrix:\n{}".format(P_R))
        print("# ----------------------------------------------------- #")

		# Check whether calculating horizontal disparity
        if(0.001 < np.fabs(P_R[1, 3])):
            err = "Calculating vertical not horizontal disparity. Take more"\
                    " tilted images."
            raise RuntimeError(err)
        # ------------------------------------------------------------------ #


        # --------------------- FIND RECTIFICATION MAPS -------------------- #
        # Find the rectification mapping transformations
        lmap1, lmap2 = cv2.initUndistortRectifyMap(cmatrixL, dcoefsL, R_L,
                            P_L, (imL.shape[1], imL.shape[0]), cv2.CV_32FC1)
        rmap1, rmap2 = cv2.initUndistortRectifyMap(cmatrixR, dcoefsR, R_R,
                            P_R, (imL.shape[1], imL.shape[0]), cv2.CV_32FC1)
        # ------------------------------------------------------------------ #



        # -------------------- VERIFY RECTIFACTION WORKS ------------------- #
        # Convert images to gray scale
        lgray_im = imL #cv2.cvtColor(imL, cv2.COLOR_BGR2GRAY)
        rgray_im = imR #cv2.cvtColor(imR, cv2.COLOR_BGR2GRAY)

        # Find the corners on the unrectified images
        corners_L = np.load(calib_path_L,allow_pickle=True)                            # MAKING EDITS HERE
        corners_R = np.load(calib_path_R,allow_pickle=True)
        ret_valL = True
        ret_valR = True
        image_cornersL = corners_L[val_num]
        image_cornersR = corners_R[val_num] # CHANGE TO FIT WITH CAL IMAGE
        #ret_valL, image_cornersL = cv2.findChessboardCorners(lgray_im, 
        #                                                num_corners, None)
        #ret_valR, image_cornersR = cv2.findChessboardCorners(rgray_im, 
        #                                                num_corners, None)

        if(not ret_valL or not ret_valR):
            err = "Corners could not be detected in images."
            raise RuntimeError(err)

        # Draw the chessboard corners on the image
        unrect_imL = cv2.drawChessboardCorners(imL.copy(), num_corners,
                                                image_cornersL, ret_valL)
        unrect_imR = cv2.drawChessboardCorners(imR.copy(), num_corners,
                                                image_cornersR, ret_valR)

        # Find the distance, in the x and y direction, between the top and
        # bottom corners of the calibration pattern
        dist1x = image_cornersL[num_corners[0]*num_corners[1]-1, 0, 0] - image_cornersL[0, 0, 0]
        dist1y = image_cornersL[num_corners[0]*num_corners[1]-1, 0, 1] - image_cornersL[0, 0, 1]
        dist2x = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 0] - image_cornersR[0, 0, 0]
        dist2y = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 1] - image_cornersR[0, 0, 1]

        print("\nBefore Rectification:")
        print("DistLx:\t{}\t\tDistLy:\t{}".format(dist1x, dist1y))
        print("DistRx:\t{}\t\tDistRy:\t{}".format(dist2x, dist2y))
        # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #

        # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
        # Rectify the left and right images
        imL = cv2.remap(imL, lmap1, lmap2, cv2.INTER_LINEAR)
        imR = cv2.remap(imR, rmap1, rmap2, cv2.INTER_LINEAR)

        # Convert the images to gray scale
        lgray_im = imL #cv2.cvtColor(imL, cv2.COLOR_BGR2GRAY)
        rgray_im = imR #cv2.cvtColor(imR, cv2.COLOR_BGR2GRAY)
           
        # Save rectified images so that manual corner selection can be carried out
        np.save(calib_filedir + r'\Rect_Left.npy', imL)
        np.save(calib_filedir + r'\Rect_Right.npy', imR)
        print("saved Rect_images")

        # Find the chessboard corners in the images
        corners_L = np.load(calib_path_RL,allow_pickle=True)                            # MAKING EDITS HERE
        corners_R = np.load(calib_path_RR,allow_pickle=True)
        ret_valL = True
        ret_valR = True
        image_cornersL = corners_L[0]
        image_cornersR = corners_R[0]                                       # NEED TO MANUALLY RESELECT FOR NOW
        #ret_valL, image_cornersL = cv2.findChessboardCorners(lgray_im,                  # DO THE SAME HERE
        #                                                num_corners, None)
        #ret_valR, image_cornersR = cv2.findChessboardCorners(rgray_im,
        #                                                num_corners, None)

        if(not ret_valL or not ret_valR):
            err = "Corners could not be detected in rectified images."
            raise RuntimeError(err)

        # Find the chessboard corners on the rectified images
        imL = cv2.drawChessboardCorners(imL, num_corners, image_cornersL,
                                                                    ret_valL)
        imR = cv2.drawChessboardCorners(imR, num_corners, image_cornersR,
                                                                    ret_valR)

        # Show the unrectified and rectified images if desired
        if(self.__calib_disp):
            plt.figure(1)
            plt.imshow(imL)#cv2.cvtColor(imL, cv2.COLOR_BGR2RGB))
            plt.title("Rectified Left Image")

            # plt.figure(2)
            # plt.imshow(cv2.cvtColor(imR, cv2.COLOR_BGR2RGB))
            # plt.title("Rectified Right Image")

            plt.figure(3)
            plt.imshow(imR)#cv2.cvtColor(imR, cv2.COLOR_BGR2RGB))
            plt.title("Rectified Right Image")

            # plt.figure(4)
            # plt.imshow(cv2.cvtColor(imR, cv2.COLOR_BGR2RGB))
            # plt.title("Rectified Right Image")

            plt.figure(5)
            plt.imshow(unrect_imL)#cv2.cvtColor(unrect_imL, cv2.COLOR_BGR2RGB))
            plt.title("Left Image")

            plt.figure(6)
            plt.imshow(unrect_imR)#cv2.cvtColor(unrect_imR, cv2.COLOR_BGR2RGB))
            plt.title("Right Image")
            plt.show()

        # Extract distances between corners in the images
        dist1x = image_cornersL[num_corners[0]*num_corners[1]-1, 0, 0] - image_cornersL[0, 0, 0]
        dist1y = image_cornersL[num_corners[0]*num_corners[1]-1, 0, 1] - image_cornersL[0, 0, 1]
        dist2x = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 0] - image_cornersR[0, 0, 0]
        dist2y = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 1] - image_cornersR[0, 0, 1]

        d21x_1 = image_cornersR[0, 0, 0] - image_cornersL[0, 0, 0]
        d21x_2 = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 0] - image_cornersL[num_corners[0]*num_corners[1]-1, 0, 0]
        d21y_1 = image_cornersR[0, 0, 1] - image_cornersL[0, 0, 1]
        d21y_2 = image_cornersR[num_corners[0]*num_corners[1]-1, 0, 1] - image_cornersL[num_corners[0]*num_corners[1]-1, 0, 1]

        print("\nAfter Rectification:")
        print("DistLx:\t{}\t\tDistLy:\t{}".format(dist1x, dist1y))
        print("DistRx:\t{}\t\tDistRy:\t{}".format(dist2x, dist2y))

        print("\nRelative Offsets:")
        print("DistRL_TLx:\t{}\t\tDistRL_TLy:\t{}".format(d21x_1, d21y_1))
        print("DistRL_BRx:\t{}\t\tDistRL_BRy:\t{}".format(d21x_2, d21y_2))
        # ------------------------------------------------------------------ #

        # --------------------- FIND THE ALIGNMENT PLANE ------------------- #
        # Print the rotation about each axes
        rotL = Rotation.from_matrix(R_L)
        deg_rotL = rotL.as_euler("xyz", degrees = True)
        rotR = Rotation.from_matrix(R_R)
        deg_rotR = rotR.as_euler("xyz", degrees = True)
        
        print("\nRotation Around Axes:")
        print("Axes Rotation Left:\t{}".format(deg_rotL))
        print("Axes Rotation Right:\t{}".format(deg_rotR))

        # Define the imaging plane of camera one
        c1_plane = np.array([[-1,-1,0], [1,-1,0], [1,1,0], [-1,1,0]]).T
        print("\nCamera planes")
        print(c1_plane)

        # Define the imaging plane of camera two
        c2_plane = np.matmul(R, c1_plane) + T
        print(c2_plane)

        # Define the rectified left and right cameras
        c1_rect_plane = np.matmul(R_L, c1_plane)
        c2_rect_plane = np.matmul(R_R, c2_plane)
        print("Rectified Camera planes")
        print(c1_rect_plane)
        print(c2_rect_plane)

        # Show the various planes in a 3D image
        if(self.__calib_disp):
            fig = plt.figure()
            ax = Axes3D(fig)
            ax.scatter(c1_plane[0, :], c1_plane[1, :], c1_plane[2, :],
                                c = "green", label = "Original Left Camera")
            ax.scatter(c2_plane[0, :], c2_plane[1, :], c2_plane[2, :],
                                c = "red", label = "Original Right Camera")
            ax.scatter(c1_rect_plane[0, :], c1_rect_plane[1, :],
                                c1_rect_plane[2, :], c = "blue",
                                label = "Post-Rectification Left Camera")
            ax.scatter(c2_rect_plane[0, :], c2_rect_plane[1, :],
                                c2_rect_plane[2, :], c = "purple",
                                label = "Post-Rectification Right Camera")
            ax.set_title("Relative Camera Positions")
            ax.set_xlabel("X-Direction")
            ax.set_ylabel("Y-Direction")
            ax.set_zlabel("Z-Direction")
            #ax.set_xlim(np.min(c2_plane[0, :])-1, np.max(c1_plane[0, :])+1)
            #ax.set_ylim(np.min(c2_plane[0, :])-1, np.max(c1_plane[0, :])+1)
            #ax.set_zlim(np.min(c2_plane[0, :])-1, np.max(c1_plane[0, :])+1)
            ax.legend(loc = "lower right")
            plt.show()
        # ------------------------------------------------------------------ #

        # Put calibration parameters into a dictionary
        calib_params = {}
        calib_params.update({"cmatrixL" : cmatrixL.tolist()})
        calib_params.update({"dcoefsL" : dcoefsL.tolist()})
        calib_params.update({"cmatrixR" : cmatrixR.tolist()})
        calib_params.update({"dcoefsR" : dcoefsR.tolist()})
        calib_params.update({"R_L" : R_L.tolist()})
        calib_params.update({"P_L" : P_L.tolist()})
        calib_params.update({"R_R" : R_R.tolist()})
        calib_params.update({"P_R" : P_R.tolist()})

        return lmap1, lmap2, rmap1, rmap2, calib_params


if(__name__ == "__main__"):
    # Handle command line arguments
    parser = ArgumentParser(description = "Calibrates a SOP system.")
    # parser.add_argument("--probe_id", type = int, default = None,
    #             help = "Specifies the ID of the probe to be calibrated.")
    # parser.add_argument("--sqr_size", type = np.float64, default = None,
    #             help = "The size of calibration squares (millimeters).")
    # parser.add_argument("--connection", type = int, default = None,
    #             help = "The type of connection used for the probe. Zero for"\
    #                     " Wi-Fi and one for USB.")
    # parser.add_argument("--im_width", type = int, default = None,
    #             help = "The width of the image in pixels.")
    # parser.add_argument("--im_height", type = int, default = None,
    #             help = "The height of the image in pixels.")
    parser.add_argument("--rows", type = int, default = 6,
                help = "The number of rows in the calibration pattern.")
    parser.add_argument("--columns", type = int, default = 9,
                help = "The number of columns in the calibration pattern.")
    parser.add_argument("--calib_disp", type = int, default = 0,
                    help = "Display calibration images.")
    parser.add_argument("--show_last", type = int, default = 0,
                    help = "Only show the last calibration image.")
    args = parser.parse_args()

    # Ensure the input values are valid
    if(args.probe_id is None):
        err = "'probe_id' must be specified."
        raise ValueError(err)

    if(args.sqr_size is None or args.sqr_size <= 0.0):
        err = "'sqr_size' must be specified and must be greater than zero."
        raise ValueError(err)

    if(args.connection is None or (args.connection != 0 and
                                                    args.connection != 1)):
        err = "'connection' must be zero or one."
        raise ValueError(err)

    if(args.im_width is None or args.im_width <= 0):
        err = "'im_width' must be specified and must be greater than zero."
        raise ValueError(err)

    if(args.im_height is None or args.im_height <= 0):
        err = "'im_height' must be specified and must be greater than zero."
        raise ValueError(err)

    if(args.calib_disp != 0 and args.calib_disp != 1):
        err = "'calib_disp' should be zero or one."
        raise ValueError(err)

    if(args.rows <= 0):
        err = "'rows' must be greater than zero."
        raise ValueError(err)

    if(args.columns <= 0):
        err = "'columns' must be greater than zero."
        raise ValueError(err)

    if(args.calib_disp != 0 and args.calib_disp != 1):
        err = "'calib_disp' should be zero or one."
        raise ValueError(err)

    if(args.show_last != 0 and args.show_last != 1):
        err = "'show_last' should be zero or one."
        raise ValueError(err)

    # Define attributes of the probe
    probe_id = args.probe_id
    res = (args.im_width, args.im_height)
    connt = Connections.USB if args.connection else Connections.WIFI
    conn = SOPConnection(connt)
    calib_size = (args.rows, args.columns)

    # Initialise a probe configuration instance and save the configuration
    cfg = SOPConfig(probe_id, res, conn, calib_size)
    cfg.save()

    # Try to calibrate the system
    calib = StereoCalibrator(4, bool(args.show_last), bool(args.calib_disp))
    lmap1, lmap2, rmap1, rmap2 = calib.calibrate((args.columns, args.rows),
                                                                args.sqr_size)

    # # Read in the images to find u and v offset
    # left = cv2.imread("/Users/kylenewman/Desktop/Left.jpg")
    # right = cv2.imread("/Users/kylenewman/Desktop/Right.jpg")

    # # plt.figure(1)
    # # plt.imshow(left)

    # # plt.figure(2)
    # # plt.imshow(right)
    # # plt.show()

    # imL = cv2.remap(left, lmap1, lmap2, cv2.INTER_LINEAR)	   # Left rectified coloured image
    # imR = cv2.remap(right, rmap1, rmap2, cv2.INTER_LINEAR)   # Right rectified coloured image

    # plt.figure(1)
    # plt.imshow(imL)

    # plt.figure(2)
    # plt.imshow(imR)
    # plt.show()











		