"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes a class for handling and maintaining the configuration of an SOP
probe.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

import json
import os

import numpy as np

from enum import Enum
from ..utils import FileManager


class Connections(Enum):
    """
    Connections

    Description:
    Enumerates the possible connection types for the probe.
    """

    WIFI = 0
    USB = 1
    BENCHTOP = 2
    DUALWIFI = 3
    DUALUSB = 4


class SOPConnection:
    """
    SOPConnection

    Description:
    Describes how the connection information associated with the SOP probe.
    """


    def __init__(
        self,
        connection: Connections,
        lip: str = None,
        lport: str = None,
        rip: str = None,
        rport: str = None):
        """
        __init__

        Description:
        Initialises an SOPConnection instance.

        Inputs:
            - connection : Connections
                Indicates the connection type that is being used.
        """

        # Ensure the input types are valid
        if(not isinstance(connection, Connections)):
            err = "'connection' should be a Connections instance."
            raise TypeError(err)

        # Check the other inputs only if connecting via Wi-Fi
        if(connection.value == 0):
            if(not isinstance(lip, str)):
                err = "'lip' should be a str instance when using Wi-Fi."
                raise TypeError(err)

            if(not isinstance(lport, str)):
                err = "'lport' should be a str instance when using Wi-Fi."
                raise TypeError(err)

            if(not isinstance(rip, str)):
                err = "'rip' should be a str instance when using Wi-Fi."
                raise TypeError(err)

            if(not isinstance(rport, str)):
                err = "'rport' should be a str instance when using Wi-Fi."
                raise TypeError(err)
        else:
            if(lip is not None):
                err = "'lip' should be None when connecting via USB."
                #raise TypeError(err)                                                             # RHYS GOT RID OF ERROR CALLS HERE

            if(not isinstance(lport, str)):
                err = "'lport' should be a str instance when connecting via"\
                        " USB."
                #raise TypeError(err)

            if(rip is not None):
                err = "'rip' should be None when connecting via USB."
                #raise TypeError(err)

            if(not isinstance(rport, str)):
                err = "'rport' should be a str instance when connecting via"\
                        " USB."
                #raise TypeError(err)

        # Save the inputs to private fields
        self.__connection = connection.value
        self.__lip = lip
        self.__lport = lport
        self.__rip = rip
        self.__rport = rport


    def to_dict(self) -> dict:
        """
        to_dict

        Descrition:
        Converts the connection information to a dictionary.

        Ouput:
            - conn_dets : dict
                The connection details in a dictionary format. This includes
                the following fields:
                    CONNECTION_TYPE
                    LEFT_IP
                    LEFT_PORT
                    RIGHT_IP
                    RIGHT_PORT
        """

        # Create the connection details
        conn_dets = {}
        conn_dets.update({"CONNECTION_TYPE" : self.__connection})
        conn_dets.update({"LEFT_IP" : self.__lip})
        conn_dets.update({"LEFT_PORT" : self.__lport})
        conn_dets.update({"RIGHT_IP" : self.__rip})
        conn_dets.update({"RIGHT_PORT" : self.__rport})

        return conn_dets


class SOPConfig:
    """
    SOPConfig

    Description:
    A class for initialising, updating and storing configuration information
    about a SOP probe.
    """

    def __init__(self, probe_id: int, cfg: dict):
        """
        Description:
        Initialises and instance of SOPConfig.

        Inputs:
            - probe_id : int
                The SOP system's identification number.
            - cfg : dict
                The configuration dictionary acquired by reading the JSON
                config file.
        """

        # Check the input parameter types
        if(not isinstance(probe_id, int)):
            err = "'probe_id' should be an int instance."
            raise TypeError(err)

        if(cfg is not None and not isinstance(cfg, dict)):
            err = "'cfg' should be a dict instance or None."
            raise TypeError(err)

        if(cfg is not None):
            # Indicate this was initialised with an existing config file
            self.__cfg_init = True

            # Save all of the parameters from the config file
            self.__probe_id = probe_id
            self.__res = cfg["RESOLUTION"]
            self.__connection = SOPConnection(
                    Connections(cfg["CONNECTION_DETAILS"]["CONNECTION_TYPE"]),
                    cfg["CONNECTION_DETAILS"]["LEFT_IP"],
                    cfg["CONNECTION_DETAILS"]["LEFT_PORT"],
                    cfg["CONNECTION_DETAILS"]["RIGHT_IP"],
                    cfg["CONNECTION_DETAILS"]["RIGHT_PORT"])
            self.__calib_size = cfg["CALIBRATION_SIZE"]
            self.__software_version = cfg["SOFTWARE_VERSION"]
            self.__calib_params = cfg["CALIBRATION_PARAMETERS"]
            self.__displ_model = cfg["DISPLACEMENT_MODEL"]
            self.__offset_vals = cfg["OFFSET_VALUES"]
            self.__search_range = cfg["SEARCH_RANGE"]
            self.__roi = cfg["ROI"]
            self.__comments = cfg["COMMENTS"]
            self.__sqr_size = cfg["SQUARE_SIZE"]
            self.__rect_corns = cfg["RECTIFICATION_CORNERS"]

        else:
            # Indicate this was initialised without an existing config file
            self.__cfg_init = False

            # Define the corner order
            corns_im = [["TLxy"], ["TRxy"], ["BRxy"], ["BLxy"]]
            corns_ww = [["TLxyz"], ["TRxyz"], ["BRxyz"], ["BLxyz"]]

            # Initialise all the instance variables
            self.__probe_id = probe_id
            self.__res = None
            self.__connection = None
            self.__calib_size = None
            self.__software_version = None
            self.__calib_params = None
            self.__displ_model = None
            self.__offset_vals = None
            self.__search_range = None
            self.__roi = None
            self.__comments = None
            self.__sqr_size = None
            self.__rect_corns = {"LEFT_CORNERS": corns_im,
                                    "RIGHT_CORNERS": corns_im,
                                    "WORLD_CORNERS": corns_ww}


    def set_res(self, res: tuple):
        """
        set_res

        Description:
        A setter method for the resolution of the system.

        Input:
            - res : tuple
                The resolution of the system. The first element is the width
                of the images in pixels and the second element is the height
                of the images in pixels.
        """

        # Check the type is correct
        if(not isinstance(res, tuple)):
            err = "'res' should be a tuple."
            raise TypeError(err)

        # Ensure the input is valid
        if(len(res) != 2 or not isinstance(res[0], int) or not
                                            isinstance(res[1], int)):
            err = "'res' should contain two integer values."
            raise ValueError(err)
        
        if(res[0] <= 0 or res[1] <= 0):
            err = "The values of 'res' should be greater than zero."
            raise ValueError(err)

        # Save the resolution to a private instance variable
        self.__res = res

        # Set the ROI
        self.__roi = {}
        if(res[1] == 720):
            # Define the ROI in the left image - for 720p images
            self.__roi.update({"top_edge": 101})
            self.__roi.update({"bottom_edge": 500})
            self.__roi.update({"left_edge": 401})
            self.__roi.update({"right_edge": 800})
        elif(res[1] == 1080):
            # Define the ROI in the left image - for 1080p images
            self.__roi.update({"top_edge": 250})
            self.__roi.update({"bottom_edge": 658})
            self.__roi.update({"left_edge": 800})
            self.__roi.update({"right_edge": 1304})
        else:
            # Define the ROI in the left image - for 1080p images
            self.__roi.update({"top_edge": 250})
            self.__roi.update({"bottom_edge": 658})
            self.__roi.update({"left_edge": 800})
            self.__roi.update({"right_edge": 1304})


    def set_connection(self, connection: SOPConnection):
        """
        set_connection

        Description:
        A setter method for the connection details of the probe.

        Input:
            - connection : SOPConnection
                Describes the connection details of the probe.
        """

        # Check the input is the right type
        if(not isinstance(connection, SOPConnection)):
            err = "'connection' should be a SOPConnection instance."
            raise TypeError(err)

        # Set the connection private instance variable
        self.__connection = connection


    def set_calib_size(self, calib_size: tuple):
        """
        set_calib_size

        Description:
        A setter method for the calibration pattern size.

        Input:
            - calib_size : tuple
                The number of rows and columns in the calibration image. This
                should contain two elements structured as (columns, rows).
        """

        # Ensure the input type is correct
        if(not isinstance(calib_size, tuple)):
            err = "'calib_size' should be a tuple instance."
            raise TypeError(err)

        # Ensure the input value is valid
        if(len(calib_size) != 2 or not isinstance(calib_size[0], int) or not
                                            isinstance(calib_size[1], int)):
            err = "'calib_size' should contain two integers."
            raise ValueError(err)

        if(calib_size[0] <= 0 or calib_size[1] <= 0):
            err = "The values of 'calib_size' should be greater than zero."
            raise ValueError(err)

        # Set the calibration size private instance variable
        self.__calib_size = calib_size


    def set_sqr_size(self, sqr_size: float):
        """
        set_sqr_size

        Description:
        A setter method for the size of the calibration squares.

        Input:
            - sqr_size : float
                The size of each square in the calibration pattern.
        """

        # Ensure the type of the input is correct
        if(not isinstance(sqr_size, float)):
            err = "'sqr_size' should be a float instance."
            raise TypeError(err)

        # Ensure the input value is correct
        if(sqr_size <= 0.0):
            err = "'sqr_size' should be greater than zero."
            raise ValueError(err)

        # Set the square size private instance variable
        self.__sqr_size = sqr_size


    def set_calib_params(self, calib_params: dict):
        """
        set_calib_params

        Description:
        Sets the private instance variable which holds the calibration
        parameters.

        Inputs:
            - calib_params : dict
                The calibration parameters required to calculate the
                rectification maps. The structure of this dictionary is:
                   {
                        "cmatrixL": val,
                        "dcoefsL": val,
                        "cmatrixR": val,
                        "dcoefsR": val,
                        "R_L": val,
                        "P_L": val,
                        "R_R": val,
                        "P_R": val
                    }
        """

        # Ensure the input type is correct
        if(not isinstance(calib_params, dict)):
            err = "'calib_params' should be a dict instance."
            raise TypeError(err)

        # Ensure the input contains all of the correct fields
        fields = ["cmatrixL", "dcoefsL", "cmatrixR", "dcoefsR", "R_L", "P_L",
                                                                "R_R", "P_R"]

        if(list(calib_params.keys()) != fields):
            err = "'calib_params' does not contain the required fields."
            raise ValueError(err)

        # Set the calib_params instance variable
        self.__calib_params = calib_params


    def set_version(self, version: str):
        """
        set_version

        Description:
        Sets the software version instance variable.

        Input:
            - version : str
                The hash of HEAD.
        """

        # Ensure the input type is correct
        if(not isinstance(version, str)):
            err = "'version' should be a str instance."
            raise TypeError(err)

        # Set the instance variable
        self.__software_version = version


    def set_displ_model(self, displ_model: list):
        """
        set_displ_model

        Description:
        Sets the displacement model to be used with this probe.

        Input:
            - displ_model : list
                The displacement model to be used by the probe. Specifically,
                this will be used to convert from disparity to displacement.
                This should be structured like:
                    [grad, constant]
                where the gradient has units of mm/pixel and the constant is
                in millimeters.
        """

        # Ensure that the input type is correct
        if(not isinstance(displ_model, list)):
            err = "'displ_model' should be a list instance."
            raise TypeError(err)

        # Ensure the values are valid
        if(0.0 < displ_model[0]):
            err = "The gradient should be less than zero."
            raise ValueError(err)

        if(displ_model[1] < 0.0):
            err = "The constant should be greater than or equal to zero."
            raise ValueError(err)

        # Set the displacement model instance variable
        self.__displ_model = displ_model


    def set_offset(self, offset: list):
        """
        set_offset

        Description:
        Sets the u and v offset of the right camera relative to the left
        camera. Specifically, if an object is placed on the imaging window,
        then a feature found in the left image can be found in the right image
        by doing the following operation:
            (u_l, v_l) + offset -> (u_r, v_r)

        Input:
            - offset : list
                The u and v offset of the right camera relative to the left
                camera. Specifically, this should be structured as:
                    [u_offset, v_offset]
        """

        # Ensure the input type is correct
        if(not isinstance(offset, list)):
            err = "'offset' should be a list instance."
            raise TypeError(err)

        # Ensure the input values are valid
        if(0 < offset[1]):
            err = "'offset[1]' should be negative for right relative to left."
            raise ValueError(err)

        # Set the offset instance variable
        self.__offset_vals = offset


    def set_srange(self, srange: list):
        """
        set_srange

        Description:
        Sets the u and v search range for finding matching pixels in the
        right image given a location in the left image.

        Input:
            - sregion : list
                A list of lists, containing the bounds of the v and u search
                ranges. Specifically, this should be structured as:
                    [[vrange_L, vrange_H], [hrange_L, hrange_H]]
        """

        # Ensure the input type is correct
        if(not isinstance(srange, list) or not isinstance(srange[0], list)):
            err = "'srange' should be a list of two lists."
            raise TypeError(err)

        # Check the number of elements is correct
        if(len(srange) != 2 or len(srange[0]) != 2 or len(srange[1]) != 2):
            err = "'srange' has an incorrect shape."
            raise ValueError(err)

        # Check the lower values are less than the higher values
        if(srange[0][1] < srange[0][0] or srange[1][1] < srange[1][0]):
            err = "'vrange_L' should be less than 'vrange_H' and 'hrange_L'"\
                    " should be less than 'hrange_H'."
            raise ValueError(err)

        # Set the offset instance variable
        self.__search_range = srange


    def set_comments(self, comments: str):
        """
        set_comments

        Description:
        Set the comments to include in the configuration file.

        Input:
            - comments : str
                Additional comments about the probe or system.
        """

        # Ensure the input type is correct
        if(not isinstance(comments, str)):
            err = "'comments' should be a str instance."
            raise TypeError(err)

        # Set the offset instance variable
        self.__comments = comments


    def to_dict(self) -> dict:
        """
        to_dict

        Description:
        Converts the SOP configuration settings to a dictionary.

        Output:
            - cfg : dict
                The configuration details for the SOP probe. This includes
                the following fields:
                    PROBE_ID
                    RESOLUTION
                    CONNECTION_DETAILS
                    CALIBRATION_SIZE
        """

        # Create the configuration dictionary
        cfg = {}
        cfg.update({"PROBE_ID" : self.__probe_id})
        cfg.update({"RESOLUTION" : self.__res})
        cfg.update({"CONNECTION_DETAILS" : self.__connection.to_dict()})
        cfg.update({"CALIBRATION_SIZE" : self.__calib_size})
        cfg.update({"SOFTWARE_VERSION" : self.__software_version})
        cfg.update({"CALIBRATION_PARAMETERS" : self.__calib_params})
        cfg.update({"DISPLACEMENT_MODEL" : self.__displ_model})
        cfg.update({"OFFSET_VALUES" : self.__offset_vals})
        cfg.update({"SEARCH_RANGE" : self.__search_range})
        cfg.update({"ROI" : self.__roi})
        cfg.update({"COMMENTS" : self.__comments})
        cfg.update({"SQUARE_SIZE" : self.__sqr_size})
        cfg.update({"RECTIFICATION_CORNERS": self.__rect_corns})
        cfg.update({"FOCAL_ADJUSTMENT": {"X": 1.0, "Y": 1.0}})

        return cfg


    def save(self):
        """
        save

        Description:
        Saves the configuration information to a JSON file.
        """

        # Define the file name
        ddir = FileManager.get_data_dir()
        pdir = ddir + "Probe_{}/".format(self.__probe_id)
        pfile = pdir + "Config.json"

        # Check that the probe directory exists
        if(not os.path.isdir(pdir)):
            os.mkdir(pdir)

        with open(pfile, "w") as fp:
            json.dump(self.to_dict(), fp)






































