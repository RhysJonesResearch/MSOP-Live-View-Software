"""
Author: Kyle Robert Newman
Date: 19 November 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Setup calibration as an importable sub-module.
******************************************************************************

******************************************************************************
Version History
V1 -> 19 November 2020

******************************************************************************
"""

# Import necesary classes to shorten referencing from outside the package
from .stereo_processor import StereoImageProcessor
from .roi_selector import ROISelector
from .old_stereo_processor import OldStereoImageProcessor