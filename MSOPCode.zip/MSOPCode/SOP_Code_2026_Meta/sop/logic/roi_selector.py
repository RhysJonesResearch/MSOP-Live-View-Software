
"""
Author: Kyle Robert Newman
Date: 5 February 2020
Company: BRITElab & OncoRes

Program Description:
The contents of this file contains the ROISelector class which allows for a fixed region
of interest (ROI) to be extracted from a left and right image pair. The size and position
of the ROI is optimised for 720p images taken from stereo cameras within the SOP probe.

Version History
V1 -> 17 December 2019
Initial implementation of the ResultsDisplayer class. This class was specifically made to
provide the user with an interface to which the region of interest (ROI) could be displayed and
selected.

V2 -> 5 February 2020
Program adjusted and renamed. Specifcally, the functionality to dynamically select the ROI
was removed and instead a fixed ROI for 720p cameras was implemented. This was done as a probe's
ROI should be fixed (thus should not change) and also the dimensions of the ROI could not be
changed without having to adjust the GPU parallelised code. Furthermore, the class was renamed
ROISelector to better represent its use in the SOP processing pipeline.

"""

import numpy as np

class ROISelector:
	"""
	ROISelector

	Description:
	This class allows the region of interest (ROI) to be extracted from the left and right
	cameras with some user specified pixel offset. Specifically, this class has been
	tailored to 720p images and should extract a ROI that maximizes the possible throughput
	of the GPU parallelised code (on Kyle's Macbook).
	"""

	def __init__(self, estimated_offset: list, res: tuple, roi: dict):
		"""
		__init__

		Description:
		A method for creating a ResultsDisplayer object.

		Inputs:
			- estimated_offset
				A list containing two integer values. The first value indicates the estimated
				horizontal pixel disparity between the left and right images (should be a 
				negative number). The second value indicates the estimated vertical pixel
				disparity between the left and right images.
			- res : tuple
				The resolution of the input image.
			- roi : dict
				The region of interest in the left image.
		"""

		# Records the number of corners defined in the ROI
		self.__corners = 0

		# Define the regions of interest
		self.__left_ROI = roi
		self.__right_ROI = {"top_edge" : -1, "left_edge" : -1, "bottom_edge" : -1, "right_edge" : -1}

		# Define the ROI in the right image (just an adjusted version of what is in the left image)
		self.__right_ROI['top_edge'] = self.__left_ROI['top_edge'] + estimated_offset[0]
		self.__right_ROI['bottom_edge'] = self.__left_ROI['bottom_edge'] + estimated_offset[0]
		self.__right_ROI['left_edge'] = self.__left_ROI['left_edge'] + estimated_offset[1]
		self.__right_ROI['right_edge'] = self.__left_ROI['right_edge'] + estimated_offset[1]

	def get_roi_images(self, search_range, left_im, right_im):
		"""
		get_roi_images

		Description:
		A method which returns the ROI from the left and right images. It should be noted that
		the region of interest in the right-hand image is simply an adjusted version of the 
		region of interest in the left-hand. Specifically, the right image ROI is expanded by
		search_range[1][0] in the left direction, search_range[1][1] in the right direction, 
		search_range[0][0] in the upwards direction and search_range[0][1] in the downwards
		direction. Furthermore, the right ROI is shifted according to the values given in
		the estimated_offset list passed to the classes constructor at the creation of an
		instance.

		Input:
			- search_range
				A list of two lists, where the first contains the search range in the v
				direction (upwards then downwards) and the second contains the search range in 
				the u direction (left then right).
			- left_im
				A np.ndarray which contains the left hand image we want to extract the ROI from.
				It is assumed that this is a grayscale image. 
			- right_im
				A np.ndarray which contains the right hand image we want to extract the ROI from.
				It is assumed that this is a grayscale image. 

		Outputs:
			- left_roi
				An np.ndarray containing the ROI of the left image which is a grayscale image.
			- right_roi
				An np.ndarray containing the ROI of the right image which is a grayscale image.
		"""

		# Extract the left image's ROI
		y0 = self.__left_ROI['top_edge']
		y1 = self.__left_ROI['bottom_edge']
		x0 = self.__left_ROI['left_edge']
		x1 = self.__left_ROI['right_edge']
		left_roi = left_im[y0:y1, x0:x1].copy()

		# Extract the right image's ROI
		y0 = self.__right_ROI['top_edge'] + search_range[0][0]
		y1 = self.__right_ROI['bottom_edge'] + search_range[0][1]
		x0 = self.__right_ROI['left_edge'] + search_range[1][0]
		x1 = self.__right_ROI['right_edge'] + search_range[1][1]
		right_roi = right_im[y0:y1, x0:x1].copy()

		return left_roi, right_roi

	def get_rois(self):
		"""
		get_rois

		Description:
		A method which returns the indexes associated with the ROIs that will be extracted
		from the left and right images.

		Outputs:
			- left_ROI
				A dictionary containing the bounding indexes of the ROI in the left image.
				The elements of the dictionary are: "top_edge", "bottom_edge", "left_edge"
				and "right_edge".
			- right_ROI
				A dictionary containing the bounding indexes of the ROI in the right image.
				The elements of the dictionary are: "top_edge", "bottom_edge", "left_edge"
				and "right_edge".
		"""

		return self.__left_ROI, self.__right_ROI



