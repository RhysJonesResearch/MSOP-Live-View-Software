"""
Author: Kyle Robert Newman
Date: 7 February 2020
Company: BRITElab & OncoRes

Program Description:
This file contains the StereoImageProcessor class which can be used to calculate the disparity
map between two images. To ensure low processing times this program was developed using 
pyopencl which is a wrapper of OpenCL (a GPU parallelisation library).

Version History
V1 -> 7 February 2020
Initial program implementation. In this implementation the StereoImageProcessor class has the
ability to rectify the images and to create a disparity map from these images (using a GPU).
Specifically, this code was optimised to run on Kyle's MacBook Pro, and for better speedup
on different devices the program should be altered.

"""

import numpy as np
import pyopencl as cl

import cv2
import os

from .roi_selector import ROISelector

os.environ['PYOPENCL_COMPILER_OUTPUT'] = '1'

class OldStereoImageProcessor:
	"""
	StereoImageProcessor

	Description:
	A class which provides the functionality required to form a disparity map from two
	input images.

	"""

	def __init__(
		self,
		lmap1: np.ndarray,
		lmap2: np.ndarray,
		rmap1: np.ndarray,
		rmap2: np.ndarray,
		estimated_offset: list,
		res: tuple,
		roi: dict):
		"""
		__init__

		Description:
		Initialises an instance of the StereoImageProcessor class.

		Inputs:
			- lmap1
	            An np.ndarray containing the x-pixel mappings to be done for the
	            retification of the left image.
	        - lmap2
	            An np.ndarray containing the y-pixel mappings to be done for the
	            retification of the left image.
	        - rmap1
	            An np.ndarray containing the x-pixel mappings to be done for the
	            retification of the right image.
	        - rmap2
	            An np.ndarray containing the y-pixel mappings to be done for the
	            retification of the right image.
	    	- estimated_offset
	    		A list containing two integer values. The first integer value is
	    		an estimate of the horizontal disparity of the right image 
	    		relative to the left image (should be a negative number). The
	    		second integer value is an estimate of the vertical disparity of
	    		the right image relative to the left image.
	    	- res : tuple
				The resolution of the input image.
			- roi : dict
				The region of interest in the left image.
		"""

		# Check the input types are correct
		if(not isinstance(lmap1, np.ndarray)):
			raise TypeError("'lmap1' should be an np.ndarray.")

		if(not isinstance(lmap2, np.ndarray)):
			raise TypeError("'lmap2' should be an np.ndarray.")

		if(not isinstance(rmap1, np.ndarray)):
			raise TypeError("'rmap1' should be an np.ndarray.")

		if(not isinstance(rmap2, np.ndarray)):
			raise TypeError("'rmap2' should be an np.ndarray.")

		if(not isinstance(estimated_offset, list)):
			raise TypeError("'estimated_offset' should be a list.")

		if(not isinstance(res, tuple)):
			raise TypeError("'res' should be a tuple.")

		if(not isinstance(roi, dict)):
			raise TypeError("'roi' should be a dict.")

		# Check input values are correct
		if(len(estimated_offset) != 2 and not isinstance(estimated_offset[0], int)):
			raise ValueError("'estimated_offset' should contain two integers.")

		if(0 < estimated_offset[1]):
			raise ValueError("Horizontal disparity should be negative if the cameras are arranged correctly.")

		# Prepare OpenCL environment for parallel execution
		self.__platform, self.__device, self.__context, self.__queue = self.__init_gpu_parallelisation()

		# Print out device parameters
		# print("Max Clock Frequency:\t{} MHz".format(self.__device.max_clock_frequency))
		# print("Max Compute Units:\t{}".format(self.__device.max_compute_units))
		# print("Max Work Group Size:\t{}".format(self.__device.max_work_group_size))

		# Initialise the OpenCL program to calculate the mean of windows
		self.__program1 = self.__init_gpu_mean_program()

		# Initialise the OpenCL program to calculate the denominator of windows
		self.__program2 = self.__init_gpu_denominator_program()

		# Initialize the OpenCL program to match windows in the left and right images
		self.__program3 = self.__init_gpu_matching_program()

		# Initialize the OpenCL median filter program
		self.__program4 = self.__init_gpu_median_filter_program()

		# Save the rectification maps to private fields
		self.__lmap1 = lmap1
		self.__lmap2 = lmap2
		self.__rmap1 = rmap1
		self.__rmap2 = rmap2

		# Save the estimated offset
		self.__estimated_offset = estimated_offset

		# Intialize an ROI selector object
		self.__roi_selector = ROISelector(estimated_offset, res, roi)


	def get_rois(self):
		"""
		get_rois

		Description:
		A method which returns the indexes associated with the ROIs that will be
		extracted from the left and right images.

		Outputs:
			- left_ROI
				A dictionary containing the bounding indexes of the ROI in the 
				left image. The elements of the dictionary are: "top_edge", 
				"bottom_edge", "left_edge" and "right_edge".
			- right_ROI
				A dictionary containing the bounding indexes of the ROI in the
				right image. The elements of the dictionary are: "top_edge", 
				"bottom_edge", "left_edge" and "right_edge".
		"""

		return self.__roi_selector.get_rois()


	def __init_gpu_parallelisation(self):
		"""
		__init_gpu_parallelisation

		Description:
		A private method which initialises the OpenCL environment so that code can 
		be run on the local GPU. To run code on a GPU we require four distinct
		initialization steps:

			1) Query the system's supported platforms.
			2) Find the GPU devices available within this platform.
			3) Create the context for the program.
			4) Establish a command queue with the created context.

		Outputs:
			- platform
				A pyopencl._cl.Platform object which specifies what hardware
				platform the GPU parallelised code should use.
			- device
				A pyopencl._cl.Device object which specifies what device on
				this platform we will be running the code on.
			- context
				A pyopencl._cl.Context object which specifies the context in
				which the program will run.
			- queue
				A pyopencl._cl.CommandQueue object where OpenCL can queue
				kernels that have to be executed.
		"""

		# Connect to a GPU
		platform = None
		try:
			# Try to connect to the NVIDIA GPU on the lab laptop
			platform = cl.get_platforms()[1]
		except:
			# Connect to the first GPU available
			platform = cl.get_platforms()[0]

		# Get the first avaliable GPU device on this platform
		device = platform.get_devices(cl.device_type.GPU)[0]

		# Create the context
		context = cl.Context([device])

		# Create a command queue
		queue = cl.CommandQueue(context)

		return platform, device, context, queue


	def __init_gpu_mean_program(self):
		"""
		__init_gpu_mean_program

		Description:
		A private method which specifies and builds the GPU parallelise code used 
		to calculate the mean of every window in an image.

		Output:
			A pyopencl.Program object which allows the mean of each window
			in an image to be calculated on a GPU.
		"""

		# Write the OpenCL program to be run
		program_text = """
		__kernel void mean_image(const int sub_spacing, const int window_size, const int im_width, const int mean_width, const float filt_elements, __global float *image, __global float *mean_im)
		{
			// Extract the position in the position in the mean array
			int pos_mean = get_global_id(0);	

			// Extract the coordinates in the image
			int jj = pos_mean / mean_width;
			int ii = pos_mean % mean_width;

			// Ensure the initial mean for this window is zero
			mean_im[pos_mean] = 0.0;

			// Calculate the mean for this starting position
			for(int kk = 0; kk < window_size; kk += sub_spacing)
			{
				int val = (jj + kk) * im_width;

				for(int mm = 0; mm < window_size; mm += sub_spacing)
				{
					// Input position
					int pos_image = val + ii + mm;

					mean_im[pos_mean] += image[pos_image];
				}
			}

			mean_im[pos_mean] /= filt_elements;
		}
		"""

		# Create the program and build it
		program = cl.Program(self.__context, program_text).build()

		return program

	def __init_gpu_denominator_program(self):
		"""
		__init_gpu_denominator_program

		Description:
		A private method which specifies and builds the GPU parallelise code used
		to calculate the denominator of each window in an image.

		Output:
			A pyopencl.Program object which allows the denominator of each window
			in an image to be calculated on a GPU.
		"""

		# Write the OpenCL program to be run
		program_text = """
		__kernel void denom_image(const int sub_spacing, const int window_size, const int im_width, const int denom_width, __global float *image, __global float *mean_im, __global float *denom_im)
		{
			// Extract the position in the position in the denom array
			int pos_denom = get_global_id(0);	

			// Extract the coordinates in the image
			int jj = pos_denom / denom_width;
			int ii = pos_denom % denom_width;

			// Ensure the initial denom for this window is zero
			denom_im[pos_denom] = 0.0;

			// Calculate the denominator for this starting position
			for(int kk = 0; kk < window_size; kk += sub_spacing)
			{
				int val = (jj + kk) * im_width;

				for(int mm = 0; mm < window_size; mm += sub_spacing)
				{
					// Input position
					int pos_image = val + ii + mm;

					denom_im[pos_denom] += (image[pos_image] - mean_im[pos_denom])*(image[pos_image] - mean_im[pos_denom]);
				}
			}

			denom_im[pos_denom] = sqrt(denom_im[pos_denom]);
		}
		"""

		# Create the program and build it
		program = cl.Program(self.__context, program_text).build()

		return program

	def __init_gpu_matching_program(self):
		"""
		__init_gpu_matching_program

		Description:
		A private method which specifies and builds the GPU parallelise code used
		to calculate the disparity map from two images.

		Output:
			A pyopencl.Program object which allows a disparity map to be calculated
			on a GPU.
		"""

		# Write the OpenCL program to be run
		program_text = """
		__kernel void match_windows(const int adjustment_u, __global int *params, __global float *left_im, __global float *right_im, __global float *left_means, __global float *right_means, __global float *left_denoms, __global float *right_denoms, __global int *uu_matches, global int *vv_matches)
		{
			// Unpack parameters
			int sub_spacing = params[0];
			int dim = params[1];
			int l_im_width = params[2];
			int r_im_width = params[3];
			int uu_range = params[4];
			int vv_range = params[5];
			int l_mean_width = params[7];
			int r_mean_width = params[8];

			// Index into left_means and left_denoms
			int left_index = get_global_id(0);

			// Extract the starting position in the left image
			int l_vv = left_index / l_mean_width;	// Vertical starting position in left image
			int l_uu = left_index % l_mean_width;	// Horizontal starting position in left image

			// Minimum cost and the associated offset
			float min_cost = 10000000000.0;
			int uu_offset = 0; // WARNING -> if true min_cost higher than the above then zero will be shown
			int vv_offset = 0;

			// Values to save work later
			int v_val = l_vv * sub_spacing;
			int u_val = l_uu * sub_spacing;

			// Make private memory to avoid global memory access
			float left_mean = left_means[left_index];
			float left_denom = left_denoms[left_index];

			// Compare each window in the right images search range to the left window
			for(int jj = 0, r_vv = v_val; jj < vv_range; jj += 2, r_vv += 2)
			{
				// r_vv -> Vertical starting position in the right image

				for(int ii = 0, r_uu = u_val; ii < uu_range; ii += 2, r_uu += 2)
				{
					// r_uu -> Horizontal starting position in the right image

					// Index into right_means and right_denoms
					int right_index = r_vv * r_mean_width  + r_uu;

					// Make private memory to avoid global memory access
					float right_mean = right_means[right_index];
					float right_denom = right_denoms[right_index];

					// Holds the cost of this window
					float cost = 0.0;

					for(int kk = 0, KK = 0; kk < dim; kk++, KK += sub_spacing)
					{
						for(int mm = 0, MM = 0; mm < dim; mm++, MM += sub_spacing)
						{
							// Index into the images
							int left_im_index = (l_vv + kk) * l_im_width + (l_uu + mm);
							int right_im_index = (r_vv + KK) * r_im_width + (r_uu + MM);

							float left_val = (left_im[left_im_index] - left_mean) / (left_denom);
							float right_val = (right_im[right_im_index] - right_mean) / (right_denom);
							
							float cur_val = left_val - right_val;
							if(cur_val < 0.0)
							{
								cost -= cur_val;
							}
							else
							{
								cost += cur_val;
							}
						}
					}

					// Store the offset associated with the minimum cost
					if(cost < min_cost)
					{
						min_cost = cost;
						uu_offset = ii;
						vv_offset = jj;
					}
				}
			}

			int old_vv_offset = vv_offset;
			int old_uu_offset = uu_offset;

			// Compare each window in the right images search range to the left window
			for(int jj = old_vv_offset - 1, r_vv = v_val + old_vv_offset - 1; jj <= old_vv_offset + 1; jj++, r_vv++)
			{
				// r_vv -> Vertical starting position in the right image

				for(int ii = old_uu_offset - 1, r_uu = u_val + old_uu_offset - 1; ii <= old_uu_offset + 1; ii++, r_uu++)
				{
					// Avoid if outside the search range
					if(jj < 0 || ii < 0)
					{
						continue;
					}

					// r_uu -> Horizontal starting position in the right image

					// Index into right_means and right_denoms
					int right_index = r_vv * r_mean_width  + r_uu;

					// Make private memory to avoid global memory access
					float right_mean = right_means[right_index];
					float right_denom = right_denoms[right_index];

					// Holds the cost of this window
					float cost = 0.0;

					for(int kk = 0, KK = 0; kk < dim; kk++, KK += sub_spacing)
					{
						for(int mm = 0, MM = 0; mm < dim; mm++, MM += sub_spacing)
						{
							// Index into the images
							int left_im_index = (l_vv + kk) * l_im_width + (l_uu + mm);
							int right_im_index = (r_vv + KK) * r_im_width + (r_uu + MM);

							float left_val = (left_im[left_im_index] - left_mean) / (left_denom);
							float right_val = (right_im[right_im_index] - right_mean) / (right_denom);
							
							float cur_val = left_val - right_val;
							if(cur_val < 0.0)
							{
								cost -= cur_val;
							}
							else
							{
								cost += cur_val;
							}
						}
					}

					// Store the offset associated with the minimum cost
					if(cost < min_cost)
					{
						min_cost = cost;
						uu_offset = ii;
						vv_offset = jj;
					}
				}
			}

			// Update the uu_matches appropriately
			vv_matches[left_index] = vv_offset;
			uu_matches[left_index] = adjustment_u - uu_offset; 
		}
		"""

		# Create the program and build it
		program = cl.Program(self.__context, program_text).build()

		return program

	def __init_gpu_median_filter_program(self):
		"""
		__init_gpu_median_filter_program

		Description:
		A private method which specifies and builds the GPU parallelise code to run
		a median filter over an image.

		Output:
			A pyopencl.Program object which allows a median filter to be run over an
			image.
		"""

		# Write the OpenCL program to be run
		program_text = """
		__kernel void median_filter(const int width, const int height, __global int *input, __global int *output)
		{
			// Get the starting position
			int pos = get_global_id(0);

			// Get starting index
			int vv = pos / width;
			int uu = pos % width;

			// Fill edges with the input value
			if(vv == 0 || uu == 0 || vv == (height - 1) || uu == (width - 1))
			{
				output[pos] = input[pos];
			}
			else
			{
				// Get neighbour indexes
				int indexes[9];
				int vals[9];
				indexes[0] = (vv - 1) * width + (uu - 1);
				indexes[1] = indexes[0] + 1;
				indexes[2] = indexes[0] + 2;
				indexes[3] = indexes[0] + width;
				indexes[4] = indexes[3] + 1;
				indexes[5] = indexes[3] + 2;
				indexes[6] = indexes[3] + width;
				indexes[7] = indexes[6] + 1;
				indexes[8] = indexes[6] + 2;

				// Fill in the vals array
				for(int ii = 0; ii < 9; ii++)
				{
					vals[ii] = input[indexes[ii]];
				}

				// Sort in ascending order
				int change = 1;
				while(change)
				{
					change = 0;

					for(int jj = 0; jj < 8; jj++)
					{
						if(vals[jj + 1] < vals[jj])
						{
							float temp = vals[jj];
							vals[jj] = vals[jj + 1];
							vals[jj + 1] = temp;
							change = 1;
						}
					}
				}

				output[pos] = vals[4];
			}
		}
		"""

		# Create the program and build it
		program = cl.Program(self.__context, program_text).build()

		return program

	def rectify(self, search_range, left_im, right_im):
		"""
		rectify

		Description:
		A method which rectifies images from the left and right cameras and then
		converts them to grayscale images and returns only the region of interest.

		Inputs:
			- search_range
				A list of two lists, where the first contains the search range in
				the v direction (upwards then downwards) and the second contains 
				the search range in the u direction (left then right).
			- left_im
				A np.ndarray which contains an image acquired from the left-hand camera.
			- right_im
				A np.ndarray which contains an image acquired from the right-hand camera.

		Outputs:
			- left_roi
				An np.ndarray containing a rectified and grayscaled region of interest taken
				from the left-hand camera.
			- right_roi
				An np.ndarray containing a rectified and grayscaled region of interest taken
				from the right-hand camera.
		"""

		# Rectify the images
		self.__lcol_im = cv2.remap(left_im, self.__lmap1, self.__lmap2, cv2.INTER_LINEAR)		# Left rectified coloured image
		self.__rcol_im = cv2.remap(right_im, self.__rmap1, self.__rmap2, cv2.INTER_LINEAR)		# Right rectified coloured image

		if(search_range is None):
			# Convert the images to gray scale
			self.__lgray_im = cv2.cvtColor(self.__lcol_im, cv2.COLOR_BGR2GRAY)
			self.__rgray_im = cv2.cvtColor(self.__rcol_im, cv2.COLOR_BGR2GRAY)
			return self.__lgray_im, self.__rgray_im

		# Convert images to gray scale
		self.__lgray_im = cv2.cvtColor(self.__lcol_im, cv2.COLOR_BGR2GRAY)
		self.__rgray_im = cv2.cvtColor(self.__rcol_im, cv2.COLOR_BGR2GRAY)

		# Extract the region of interest from the grayscale images
		self.__lgray_im, self.__rgray_im = self.__roi_selector.get_roi_images(search_range, self.__lgray_im, self.__rgray_im)

		return self.__lgray_im, self.__rgray_im


	def get_disparity(self, sub_spacing, window_size, search_range):
		"""
		get_disparity

		Description:
		A method used to find the disparity map from the left and right cameras'
		region of interest (ROI). This method calculates the disparity map using a 
		method similar to NCORR. Specifically, it extracts small windows from the left 
		and right ROIs and tries to match them by moving the window in the right ROI.
		For each window in the left image two disparity values are returned indicating
		the horizontal and vertical disparity of this window relative to the window
		in the right image. In order to determine which two windows match a normalized
		mean square error cost function is used.

		Inputs:
			- sub_spacing
				An integer representing the spacing between sampled pixels within a window.
				Specifically, the windows can be compared by only taking a few pixel samples
				rather than comparing each pixel within the window. This variable allows the
				spacing between the samples to be changed. It should be noted that changes in
				this parameter tradeoff accuray and performance. It is recommended that the
				sub_spacing is set to 3.
			- window_size
				An integer representing the size of the windows to compare. It is recommended
				that this value is set to 25. If the user wishes to use a different value then
				they should note that increasing the window size increases the execution time
				and can cause erroneous results as large windows may not have a uniform 
				disparity throughout. Furthermore, if the window size is decreased then the
				number of samples may be inadequate to accurately find matching windows.
			- search_range
				A list of two lists, where the first contains the search range in
				the v direction (upwards then downwards) and the second contains 
				the search range in the u direction (left then right).

		Outputs:
			- uu_matches
				An np.ndarray which contains the horizontal disparity image.
		"""

		# ************************************************************************************* #
		# 						RUN THE MEAN PROGRAM ON THE LEFT IMAGE							#
		#																						#
		# ************************************************************************************* #

		# Sample the left image at a frequency of "sub_spacing"
		left_gray = self.__lgray_im[0:-1:sub_spacing, 0:-1:sub_spacing].copy()
		right_gray = self.__rgray_im.copy()

		# Width and height of the window post sampling
		dim = np.int32((window_size - 1) / (sub_spacing)) + 1

		# Create the constants required to run the program
		window_size = np.int32(window_size)							# Size of the windows to use
		sub_spacing = np.int32(sub_spacing)							# Spacing of samples in the window
		lower_u_search = np.int32(search_range[1][0])				# Lower bound of the search range in the u-direction
		estimated_offset_u = np.int32(self.__estimated_offset[1])	# Estimated offset in the u-direction
		adjustment_u = - lower_u_search - estimated_offset_u		# The value to adjust the disparity by
		l_im_height = np.int32(left_gray.shape[0])					# Height of the left image
		l_im_width = np.int32(left_gray.shape[1])					# Width of the left image
		l_mean_height = np.int32(l_im_height - dim + 1)				# Height of the left mean matrix
		l_mean_width = np.int32(l_im_width - dim + 1)				# Width of the left mean matrix
		r_im_height = np.int32(right_gray.shape[0])					# Height of the right image
		r_im_width = np.int32(right_gray.shape[1])					# Width of the right image
		r_mean_width = np.int32(r_im_width - window_size + 1)		# Width of the right mean matrix
		filter_elements = np.float32(dim * dim)						# Number of elements in the filter (post sampling)

		# Reshape the images so that it is flat
		left_gray = left_gray.reshape((left_gray.shape[0] * left_gray.shape[1],)).astype(np.float32)
		right_gray = right_gray.reshape((right_gray.shape[0] * right_gray.shape[1],)).astype(np.float32)

		# Create buffer space for the input data to be given to the device (only for left image processing)
		left_img_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = left_gray)		# Buffer for image input
		left_mean = np.zeros(((l_im_height - dim + 1) * (l_im_width - dim + 1),), dtype = np.float32)
		left_mean_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, left_mean.nbytes)									# Buffer for mean output

		# Find the means and store in host program memory
		self.__program1.mean_image(self.__queue, left_mean.shape, (256,), np.int32(1), np.int32(dim), l_im_width, l_mean_width, filter_elements, left_img_buff, left_mean_buff)
		cl.enqueue_copy(self.__queue, left_mean, left_mean_buff)
		# ************************************************************************************* #





		# ************************************************************************************* #
		# 						RUN THE MEAN PROGRAM ON THE RIGHT IMAGE							#
		#																						#
		# ************************************************************************************* #

		# Create buffer space for the input data to be given to the device (only for left image processing)
		right_img_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = right_gray)	# Buffer for image input
		right_mean = np.zeros(((r_im_height - window_size + 1) * (r_im_width - window_size + 1),), dtype = np.float32)
		right_mean_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, right_mean.nbytes)									# Buffer for mean output

		# Find the means and store in host program memory
		# LARGE ROI SIZE -> (227,)
		# SMALL ROI SIZE -> (252,)
		self.__program1.mean_image(self.__queue, right_mean.shape, (240,), sub_spacing, window_size, r_im_width, r_mean_width, filter_elements, right_img_buff, right_mean_buff)
		cl.enqueue_copy(self.__queue, right_mean, right_mean_buff)
		# ************************************************************************************* #





		# ************************************************************************************* #
		# 					RUN THE DENOMINATOR PROGRAM ON THE LEFT IMAGE						#
		#																						#
		# ************************************************************************************* #
		
		# Allocate device memory for the denominator calculation program
		left_mean_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = left_mean)
		left_denom = np.zeros(((l_im_height - dim + 1) * (l_im_width - dim + 1),), dtype = np.float32)
		left_denom_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, left_denom.nbytes)

		# Find the denominators and store in host program memory
		self.__program2.denom_image(self.__queue, left_denom.shape, (256,), np.int32(1), np.int32(dim), l_im_width, l_mean_width, left_img_buff, left_mean_buff, left_denom_buff)
		cl.enqueue_copy(self.__queue, left_denom, left_denom_buff)
		# ************************************************************************************* #





		# ************************************************************************************* #
		# 					RUN THE DENOMINATOR PROGRAM ON THE RIGHT IMAGE						#
		#																						#
		# ************************************************************************************* #
		
		# Allocate device memory for the denominator calculation program
		right_mean_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = right_mean)
		right_denom = np.zeros(((r_im_height - window_size + 1) * (r_im_width - window_size + 1),), dtype = np.float32)
		right_denom_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, right_denom.nbytes)

		# Find the denominators and store in host program memory
		# LARGE ROI SIZE -> (227,)
		# SMALL ROI SIZE -> (252,)
		self.__program2.denom_image(self.__queue, right_denom.shape, (240,), sub_spacing, window_size, r_im_width, r_mean_width, right_img_buff, right_mean_buff, right_denom_buff)
		cl.enqueue_copy(self.__queue, right_denom, right_denom_buff)
		# ************************************************************************************* #





		# ************************************************************************************* #
		# 							FIND ALL MATCHING WINDOWS									#
		#																						#
		# ************************************************************************************* #

		# Create a structure with all parameters required for window matching
		uu_abs_range = np.int32(abs(search_range[1][1] - search_range[1][0]))
		vv_abs_range = np.int32(abs(search_range[0][1] - search_range[0][0]))
		params = np.zeros((9,), dtype = np.int32)
		params[0] = sub_spacing
		params[1] = np.int32(dim)
		params[2] = l_im_width 			# Left image width
		params[3] = r_im_width          # Right image width
		params[4] = uu_abs_range
		params[5] = vv_abs_range
		params[6] = window_size
		params[7] = l_mean_width 		# Left mean width
		params[8] = r_mean_width		# Right mean width

		# Allocate device memory for the window matching
		params_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = params)
		left_denom_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = left_denom)
		right_denom_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = right_denom)
		uu_matches = np.zeros(((l_im_height - dim + 1) * (l_im_width - dim + 1),), dtype = np.int32)
		uu_matches_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, uu_matches.nbytes)
		vv_matches = np.zeros(((l_im_height - dim + 1) * (l_im_width - dim + 1),), dtype = np.int32)
		vv_matches_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, uu_matches.nbytes)

		# Find the uu offset for all windows in the left image
		self.__program3.match_windows(self.__queue, uu_matches.shape, (256,), adjustment_u, params_buff, left_img_buff, right_img_buff, left_mean_buff, right_mean_buff, left_denom_buff, right_denom_buff, uu_matches_buff, vv_matches_buff)
		cl.enqueue_copy(self.__queue, uu_matches, uu_matches_buff)
		cl.enqueue_copy(self.__queue, vv_matches, vv_matches_buff)
		# ************************************************************************************* #





		# ************************************************************************************* #
		# 						PASS OUTPUT THROUGH A MEDIAN FILTER								#
		#																						#
		# ************************************************************************************* #

		# Release buffers
		left_img_buff.release()
		left_mean_buff.release()
		left_denom_buff.release()
		right_img_buff.release()
		right_mean_buff.release()
		right_denom_buff.release()

		# Allocate device memory for the median filter
		uu_matches.astype(np.int32)
		uu_matches_buff = cl.Buffer(self.__context, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf = uu_matches)
		new_uu_matches = uu_matches.copy().astype(np.int32)
		new_uu_matches_buff = cl.Buffer(self.__context, cl.mem_flags.WRITE_ONLY, new_uu_matches.nbytes)


		self.__program4.median_filter(self.__queue, new_uu_matches.shape, (256,), l_mean_width, l_mean_height, uu_matches_buff, new_uu_matches_buff)
		cl.enqueue_copy(self.__queue, new_uu_matches, new_uu_matches_buff)

		# ************************************************************************************* #

		uu_matches = new_uu_matches.reshape((l_im_height - dim + 1, l_im_width - dim + 1))

		return uu_matches


