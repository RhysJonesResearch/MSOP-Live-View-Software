"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Setup utils as an importable submodule.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

# Import necesary classes to shorten referencing from outside the package
from .file_manager import FileManager
from .sop_exceptions import ConfigNotDefinedError