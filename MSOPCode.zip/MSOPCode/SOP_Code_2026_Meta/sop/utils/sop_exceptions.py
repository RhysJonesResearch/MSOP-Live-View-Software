"""
Author: Kyle Robert Newman
Date: 19 November 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes exception classes for displaying specific errors that can occur in
the running of the SOP code.
******************************************************************************

******************************************************************************
Version History
V1 -> 19 November 2020

******************************************************************************
"""

class ConfigNotDefinedError(Exception):
    """
    ConfigNotDefinedError

    Description:
    An exception which should be raised when the configuration file associated
    with a specific probe can not be found.
    """