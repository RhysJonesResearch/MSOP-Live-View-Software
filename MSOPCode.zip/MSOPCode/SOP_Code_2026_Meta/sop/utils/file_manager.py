"""
Author: Kyle Robert Newman
Date: 29 October 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Includes functions for finding different files and directories in the SOP code
pipeline.
******************************************************************************

******************************************************************************
Version History
V1 -> 29 October 2020

******************************************************************************
"""

import os
import platform

# Change the "slash" character depending on the operating system.
slash = "/"
if(platform.system() != "Darwin"):
    slash = "\\"

class FileManager:
    """
    FileManager

    Description:
    Provides utility functions for finding various files and directories in
    the SOP codebase.
    """

    @staticmethod
    def get_sop_dir() -> str:
        """
        get_data_dir

        Description:
        Find the directory where the SOP application is located.

        Output:
            - sop_dir : str
                The directory that 
        
        Raises:
            - RuntimeError
                When running the program from outside the application itself.
        """

        # Find the current working directory
        cwd = os.getcwd()
        cwd_split = cwd.split(slash)

        # Find the location of the application directory
        try:
            idx = cwd_split.index("StereoOpticalPalpation")
        except ValueError:
            err = "Running from the application from an invalid directory.\n"\
                    "Run from a location within StereoOpticalPalpation."
            raise RuntimeError(err)

        # Find the SOP directory
        sop_dir = slash
        for ii in range(1, idx+1):
            sop_dir += cwd_split[ii] + slash

        return sop_dir


    @staticmethod
    def get_data_dir():
        """
        get_data_dir

        Description:
        Find the directory where the SOP data is stored.
        """

        # Get the SOP directory and append the data directory on the end
        data_dir = FileManager.get_sop_dir() + "SOP_Data{}".format(slash)

        return data_dir


    @staticmethod
    def get_probe_dir(probe_id: int):
        """
        get_probe_dir

        Description:
        Find the directory where the probe data is.
        """

        # Get the SOP data directory and append the probe directory to it
        probe_dir = FileManager.get_data_dir() + "Probe_{}{}".format(probe_id,
                                                                        slash)

        return probe_dir


    @staticmethod
    def get_scans_dir(probe_id: int):
        """
        get_scans_dir

        Description:
        Finds the directory where the probe's scans can be found.

        Input:
            - probe_id : int
                The identification number associated with the probe.
        """

        # Find the scans directory
        scans_dir = FileManager.get_probe_dir(probe_id) + "Scans{}".format(
                                                                        slash)

        return scans_dir


    @staticmethod
    def get_left_dir(probe_id: int):
        """
        get_probe_dir

        Description:
        Find the directory where the left camera images are stored.
        """

        # Get the probe directory and append the left directory to it
        left_dir = FileManager.get_probe_dir(probe_id) + "Left{}".format(
                                                                        slash)

        return left_dir


    @staticmethod
    def get_right_dir(probe_id: int):
        """
        get_right_dir

        Description:
        Find the directory where the right camera images are stored.
        """

        # Get the probe directory and append the left directory to it
        right_dir = FileManager.get_probe_dir(probe_id) + "Right{}".format(
                                                                        slash)

        return right_dir


    @staticmethod
    def get_disp_dist_dir(probe_id: int):
        """
        get_disp_dist_dir

        Description:
        Find the directory where the disparity to displacement images and data
        can be found.

        Input:
            - probe_id : int
                The identification number associated with the probe.
        """

        # Get the probe directory and append the left directory to it
        dirr = (FileManager.get_probe_dir(probe_id) +
                    "Disparity_Displacement{}".format(slash))

        return dirr


    @staticmethod
    def get_slash():
        """
        get_slash

        Description:
        Find the "slash" used in defining file paths. This is operating system
        dependent.
        """
        global slash
        return slash


    @staticmethod
    def mkdir(path: str):
        """
        mkdir

        Description:
        Makes a directory if it doesn't already exist.

        Input:
            - path : str
                The path of the directory that we want to make.
        """
        global slash

        # Ensure the path style is correct
        if(path[-1] != slash):
            err = "The passed path needs to end in a '{}'.".format(slash)

        # Make the directory if it doesn't already exist
        if(not os.path.isdir(path)):
            os.mkdir(path)










































