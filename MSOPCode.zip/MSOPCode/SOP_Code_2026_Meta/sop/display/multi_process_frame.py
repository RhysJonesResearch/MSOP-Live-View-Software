import cv2
import time

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.ndimage import median_filter

from ximea import xiapi
from datetime import datetime
from ..logic import StereoImageProcessor
from .colormaps import ColorMaps
from ..utils import FileManager

# Required for record button on toolbar
import matplotlib
matplotlib.rcParams["toolbar"] = "toolmanager"
from matplotlib.backend_tools import ToolToggleBase
from matplotlib.backend_tools import ToolBase

from scipy.interpolate import griddata

def get_transitioning_pixels(image):
    """
    Identify transitioning pixels where the value differs from at least one neighbor,
    including diagonal neighbors.

    Parameters:
    image (np.ndarray): 2D numpy array representing the image.

    Returns:
    List of tuples: (coordinate, list of neighbors) for each transitioning pixel.
    """
    transitioning_pixels = []
    # Get the shape of the image
    x_dim, y_dim = image.shape

    # Define the neighbor offsets (8-connected neighbors in 2D)
    neighbors_offsets = [
        (1, 0), (-1, 0),   # Horizontal neighbors
        (0, 1), (0, -1),   # Vertical neighbors
        (1, 1), (-1, -1),  # Diagonal neighbors
        (1, -1), (-1, 1)   # Diagonal neighbors
    ]

    # Iterate through each pixel in the image
    for x in range(x_dim):
        for y in range(y_dim):
            current_value = image[x, y]
            
            # check border
            if x == 0 or y == 0 or x == x_dim-1 or y == y_dim-1:
                transitioning_pixels.append([x,y,current_value])
                continue
            
            # Check all neighbors
            for dx, dy in neighbors_offsets:
                nx, ny = x + dx, y + dy
                # Check if neighbor is within bounds
                if 0 <= nx < x_dim and 0 <= ny < y_dim:
                    neighbor_value = image[nx, ny]
                    if neighbor_value > current_value:
                        transitioning_pixels.append([x,y,current_value])
                        break
            
    return transitioning_pixels


class MultiProcessFrame:

    def __init__(
        self,
        stereo_pro: StereoImageProcessor,
        conn: dict,
        res: tuple,
        disp_model: list,
        search_range: list,
        sub_spacing: int,
        window_size: int,
        estimated_offset: list,
        layer_thickness: float,
        speckle_height: float):
        """
        __init__

        Description:

        Inputs:

        Outputs:

        """
        
        self.filedir = r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_2025\Scans\2025_Test'
        self.suffix = r'_reproc_20251024'
        self.fname = r'2mm_MoreParticles'
        self.ImageNumberStart = 8
        self.ImageNumberEnd = 8
        
        #self.ImRange = list((np.asarray([2,6,10,12,16,19,22,24,27,30,33,35,37,39,41])+1))
        self.ImRange = range(self.ImageNumberStart,self.ImageNumberEnd+1)
        #self.ImRange = [8]
        
        self.res = res

        # Check that the input types are correct
        if(not isinstance(stereo_pro, StereoImageProcessor)):
            err = "'stereo_pro' must be a StereoImageProcessor object."
            raise TypeError(err)

        if(not isinstance(conn, dict)):
            err = "'conn' should be a dict instance."
            raise TypeError(err)

        if(not isinstance(res, tuple)):
            err = "'res' should be a tuple instance."
            raise TypeError(err)

        if(not isinstance(disp_model, list)):
            err = "'disp_model' should be a list instance."
            raise TypeError(err)

        if(not isinstance(search_range, list)):
            err = "'search_range' should be a list."
            raise TypeError(err)

        if(not isinstance(sub_spacing, int)):
            err = "'sub_spacing' should be a int."
            raise TypeError(err)

        if(not isinstance(window_size, int)):
            err = "'window_size' should be a int."
            raise TypeError(err)

        if(not isinstance(estimated_offset, list)):
            err = "'estimated_offset' should be a list."
            raise TypeError(err)

        if(not isinstance(layer_thickness, float)):
            err = "'layer_thickness' should be a float."
            raise TypeError(err)

        if(not isinstance(speckle_height, float)):
            err = "'speckle_height' should be a float."
            raise TypeError(err)

        # Save the stereo processor to a private field
        self.__stereo_pro = stereo_pro

        # Save the search range to a private field
        self.__search_range = search_range

        # Save sub_spacing and window_size to private fields
        self.__sub_spacing = sub_spacing
        self.__window_size = window_size

        # Save the estimated offset to a private field
        self.__estimated_offset = estimated_offset

        # Save the layer thickness and speckle hieght to a private fields
        self.__layer_thickness = layer_thickness
        self.__speckle_height = speckle_height
        self.__speckle_depth = self.__layer_thickness - self.__speckle_height

        # Define strain to stress parameters
        #self.__AA = 0.022479
        #self.__BB = 3.5987
        #self.__CC = -0.021772
        #self.__DD = 3.2488
        
        self.__A0 = 0
        self.__AA = -2.79709
        self.__BB = -3.52231
        self.__CC = 2.8478
        self.__DD = 1.98350

        # Save the displacement model to private instance variables
        self.__disp_model = disp_model

        # Save the connection type
        self.__connt = conn["CONNECTION_TYPE"]


    def multi_proc_save(self, probe_id: int = None):
        """
        display_live

        Description:

        """
        # Setup output directory
        # Find the formatted time
        tt = datetime.today()
        ft = tt.strftime("%Y%m%d_%Hh%Mm%Ss")

        # save in same directory as new image
        ssdir = self.filedir + FileManager.get_slash()
        
        res = self.res
        
        for ImNum in self.ImRange:
            #image = cv2.imread(self.filedir + r'\Image' +str(ImNum) + '.bmp')
            image = cv2.imread(self.filedir + r'\\' + self.fname + '.bmp')
            image[:, :, 2] = 0
            im = np.asarray(image)
            
            #im = median_filter(im, size=15)
            
            #print(np.shape(image))
            #print(np.size(im))
            im1 = im[:,0:int(res[0])]
            im2 = im[:,int(res[0]):int(res[0]*2)]
        

            proc_start = time.time()

            # Rectify the images
            lgray_rec, rgray_rec = self.__stereo_pro.rectify(self.__search_range, im1, im2) # insert artifact after this to check fov's # get rid of , 1

            #print(ssdir + "lgray_rec" +str(ImNum) + self.suffix)
            np.save(ssdir + "lgray_rec" +str(ImNum) + self.suffix, lgray_rec)
            normalized = cv2.normalize(lgray_rec, None, 0, 255, cv2.NORM_MINMAX)
            image_uint8 = normalized.astype(np.uint8)
            cv2.imwrite(ssdir + "lgray_rec_" + self.fname + self.suffix + '.png', image_uint8)
            np.save(ssdir + "rgray_rec" +str(ImNum) + self.suffix, rgray_rec)
            normalized = cv2.normalize(rgray_rec, None, 0, 255, cv2.NORM_MINMAX)
            image_uint8 = normalized.astype(np.uint8)
            cv2.imwrite(ssdir + "rgray_rec_" + self.fname + self.suffix + '.png', image_uint8)

            # Find the disparity image
            disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing,
                                        self.__window_size, self.__search_range)

            # Cut out noise
            du = np.mean(disp_map)
            dstd = np.std(disp_map)
            idx_x, idx_y = np.where(2.0*dstd < np.abs(disp_map-du))    # THIS WAS ORIGINALLY JUST BEFORE DISPLAY
            #idx_x, idx_y = np.where(10 < np.abs(disp_map-du))
            disp_map = disp_map.astype(np.float64)
            #disp_map[idx_x, idx_y] = np.nan
            
            np.save(ssdir + "disp_cont_image_" +str(ImNum) + self.suffix, disp_map)
            normalized = cv2.normalize(disp_map, None, 0, 255, cv2.NORM_MINMAX)
            image_uint8 = normalized.astype(np.uint8)
            cv2.imwrite(ssdir + "disp_cont_image_" + self.fname + self.suffix + '.png', image_uint8)
            
            # Implement processing to go from contour-like image to interpolated
            # transition pixels
            transitioning_pixels = get_transitioning_pixels(np.asarray(disp_map))
            arr_transitioning_pixels = np.asarray(transitioning_pixels)

            # Interpolated image
            positions = arr_transitioning_pixels[:,0:2]
            data = arr_transitioning_pixels[:,2]

            k = 1 # 1/10

            xx = np.linspace(0, disp_map.shape[0], int(np.floor(disp_map.shape[0]*k)), endpoint=False)
            yy = np.linspace(0, disp_map.shape[1], int(np.floor(disp_map.shape[1]*k)), endpoint=False)
            X, Y = np.meshgrid(xx, yy, indexing='ij')

            disp_map = griddata(positions, data, (X, Y), method='linear')
            
            left_ROI, right_ROI = self.__stereo_pro.get_rois()

            # Convert disparity to displacement
                        # Convert disparity to displacement
            try:
                m = np.load(r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_'+str(probe_id)+r'\Scans'+r'\m_image'+'.npy')
                c = np.load(r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_'+str(probe_id)+r'\Scans'+r'\c_image'+'.npy')
                try:
                    mcROI = np.load(r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_'+str(probe_id)+r'\Scans'+r'\mcROI'+'.npy')
                    mcWindow = np.load(r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_'+str(probe_id)+r'\Scans'+r'\mcWindow'+'.npy')
                    mcROI_flag = 1
                except Exception as e:
                    print('Error: No indicator of ROI for 2D disparity to displacment map')
                    print("Error:", e)  # Prints the error message
                    mcROI_flag = 0
                
                if m.shape == disp_map.shape:
                    dist_map = m * disp_map + c # pixel by pixel map intended for use with specific config - post settings, need to recalculate for any changes
                elif (m.shape[0] > disp_map.shape[0]) and (m.shape[1] > disp_map.shape[1]) and mcROI_flag==1:       # THIS NEEDS TO BE CHANGED TO CARE ABOUT ROI VALUES INSTEAD OF SHAPE FOR TRANSLATIONS
                    print('Warning: Interpolating 2D disparity to displacement map')
                    xx = np.linspace(mcROI[0], mcROI[1]-mcWindow, mcROI[1]-mcROI[0]-mcWindow, endpoint=False)
                    yy = np.linspace(mcROI[2], mcROI[3]-mcWindow, mcROI[3]-mcROI[2]-mcWindow, endpoint=False)
                    X, Y = np.meshgrid(xx, yy, indexing='ij')
                    points = np.vstack((X.ravel(), Y.ravel())).T
                    m_points = m.ravel()
                    c_points = c.ravel()
                    xx = np.linspace(left_ROI['top_edge'], left_ROI['bottom_edge']-self.__window_size, left_ROI['bottom_edge']-left_ROI['top_edge']-self.__window_size, endpoint=False)
                    yy = np.linspace(left_ROI['left_edge'], left_ROI['right_edge']-self.__window_size, left_ROI['right_edge']-left_ROI['left_edge']-self.__window_size, endpoint=False)
                    X, Y = np.meshgrid(xx, yy, indexing='ij')
                    m_new = griddata(points, m_points, (X, Y), method='linear')
                    c_new = griddata(points, c_points, (X, Y), method='linear')
                    dist_map = m_new * disp_map + c_new
                elif ((m.shape[0] < disp_map.shape[0]) or (m.shape[1] < disp_map.shape[1])) and mcROI_flag==1:
                    print('Error: Extrapolating 2D disparity to displacement map using nearest value method')
                    xx = np.linspace(mcROI[0], mcROI[1]-mcWindow, mcROI[1]-mcROI[0]-mcWindow, endpoint=False)
                    yy = np.linspace(mcROI[2], mcROI[3]-mcWindow, mcROI[3]-mcROI[2]-mcWindow, endpoint=False)
                    X, Y = np.meshgrid(xx, yy, indexing='ij')
                    points = np.vstack((X.ravel(), Y.ravel())).T
                    m_points = m.ravel()
                    c_points = c.ravel()
                    xx = np.linspace(left_ROI['top_edge'], left_ROI['bottom_edge']-self.__window_size, left_ROI['bottom_edge']-left_ROI['top_edge']-self.__window_size, endpoint=False)
                    yy = np.linspace(left_ROI['left_edge'], left_ROI['right_edge']-self.__window_size, left_ROI['right_edge']-left_ROI['left_edge']-self.__window_size, endpoint=False)
                    X, Y = np.meshgrid(xx, yy, indexing='ij')
                    m_new = griddata(points, m_points, (X, Y), method='nearest')
                    c_new = griddata(points, c_points, (X, Y), method='nearest')
                    dist_map = m_new * disp_map + c_new
                else:
                    print('Error: Using 1D disparity to displacement')
                    dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1] # old 1D version
            except Exception as e:
                print('Error: Using 1D disparity to displacement')
                print("Error:", e)  # Prints the error message
                dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1] # old 1D version
            
            # Convert displacement to strain
            strain_map = 1 - (dist_map * (1 + self.__speckle_height 
                            / self.__speckle_depth)) / (self.__layer_thickness)

            # Convert strain to stress (in kPa)
            stress_map = self.__A0 + (self.__AA * np.exp(self.__BB * strain_map) +
                                self.__CC * np.exp(self.__DD * strain_map))

            #left_ROI, right_ROI = self.__stereo_pro.get_rois()

            # Create the rectangles to draw onto the images
            ly = left_ROI['top_edge']
            lx = left_ROI['left_edge']
            ldy = left_ROI['bottom_edge'] - left_ROI['top_edge']
            ldx = left_ROI['right_edge'] - left_ROI['left_edge']
            rect1 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                        edgecolor = 'r', facecolor = 'none')
            ry = right_ROI['top_edge']
            rx = right_ROI['left_edge']
            rdy = right_ROI['bottom_edge'] - right_ROI['top_edge']
            rdx = right_ROI['right_edge'] - right_ROI['left_edge']
            rect2 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                        edgecolor = 'r', facecolor = 'none')
            
            # Create the rectangles to draw onto the images
            ly = self.__window_size/2
            lx = self.__window_size/2
            ldy = left_ROI['bottom_edge'] - left_ROI['top_edge'] - self.__window_size
            ldx = left_ROI['right_edge'] - left_ROI['left_edge'] - self.__window_size
            rect3 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                        edgecolor = 'r', facecolor = 'none')
            
            # Create the rectangles to draw onto the images
            ry = self.__window_size/2
            rx = self.__window_size/2
            rdy = right_ROI['bottom_edge'] - right_ROI['top_edge'] - self.__window_size
            rdx = right_ROI['right_edge'] - right_ROI['left_edge'] - self.__window_size
            rect4 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                        edgecolor = 'r', facecolor = 'none')


            proc_end = time.time()
            print("Process Time:\t{}".format(proc_end - proc_start))

            np.save(ssdir + "im1_image_" +str(ImNum) + self.suffix, im1)
            print(ssdir + "im1_image_" + self.fname + self.suffix + '.png')
            cv2.imwrite(ssdir + "im1_image_" + self.fname + self.suffix + '.png', im1)
            cv2.imwrite(ssdir + "im1_ROI_" + self.fname + self.suffix + '.png', im1[int(left_ROI['top_edge']):int(left_ROI['bottom_edge']),int(left_ROI['left_edge']):int(left_ROI['right_edge'])])
            np.save(ssdir + "im2_image_" +str(ImNum) + self.suffix, im2)
            cv2.imwrite(ssdir + "im2_image_" + self.fname + self.suffix + '.png', im2)
            np.save(ssdir + "disp_map_image_" +str(ImNum) + self.suffix, disp_map)
            normalized = cv2.normalize(disp_map, None, 0, 255, cv2.NORM_MINMAX)
            image_uint8 = normalized.astype(np.uint8)
            cv2.imwrite(ssdir + "disp_map_image_" + self.fname + self.suffix + '.png', image_uint8)
            np.save(ssdir + "dist_map_image_" +str(ImNum) + self.suffix, dist_map)
            #cv2.imwrite(ssdir + "dist_map_image_" + self.fname + self.suffix + '.png', dist_map)
            np.save(ssdir + "strain_map_image_" +str(ImNum) + self.suffix, strain_map)
            #cv2.imwrite(ssdir + "strain_map_image_" + self.fname + self.suffix + '.png', strain_map)
            np.save(ssdir + "stress_map_image_" +str(ImNum) + self.suffix, stress_map)
            #scaled = cv2.normalize(stress_map, None, 0, 255, cv2.NORM_MINMAX)
            #scaled = scaled.astype(np.uint8)
            #cv2.imwrite(ssdir + "stress_map_image_" + self.fname + self.suffix + '.png', scaled)
            np.save(ssdir + "im1_ROI_" +str(ImNum) + self.suffix, left_ROI)
            np.save(ssdir + "im2_ROI_" +str(ImNum) + self.suffix, right_ROI)
            np.save(ssdir + "window_" +str(ImNum) + self.suffix, self.__window_size)
            np.save(ssdir + "LT_" +str(ImNum) + self.suffix, self.__layer_thickness)
            
            print("Save Time:\t{}".format(time.time() - proc_end))
        




