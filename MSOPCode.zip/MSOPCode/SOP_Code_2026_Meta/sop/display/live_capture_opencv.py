import cv2

from ..logic import StereoImageProcessor

import time
import numpy as np

class LiveCapture:
	"""
	LiveCapture

	Description:

	"""

	def __init__(self, stereo_pro, search_range, sub_spacing, window_size):
		"""
		__init__

		Description:

		Inputs:

		Outputs:

		"""

		# Check that the input types are correct
		if(not isinstance(stereo_pro, StereoImageProcessor)):
			raise TypeError("'stereo_pro' must be a StereoImageProcessor object.")

		if(not isinstance(search_range, list)):
			raise TypeError("'search_range' should be a list.")

		if(not isinstance(sub_spacing, int)):
			raise TypeError("'sub_spacing' should be a int.")

		if(not isinstance(window_size, int)):
			raise TypeError("'window_size' should be a int.")

		# Initialise a video capture for both devices
		# self.__left_cap = cv2.VideoCapture(1)
		# self.__right_cap = cv2.VideoCapture(0)

		self.__left_cap = cv2.VideoCapture("http://172.20.10.9:8196/")
		self.__right_cap = cv2.VideoCapture("http://172.20.10.4:8197/")

		# Change resolution to 720p
		self.__left_cap.set(3, 1280)
		self.__left_cap.set(4, 720)
		self.__right_cap.set(3, 1280)
		self.__right_cap.set(4, 720)

		# Save the stereo processor to a private field
		self.__stereo_pro = stereo_pro

		# Save the search range to a private field
		self.__search_range = search_range

		# Save sub_spacing and window_size to private fields
		self.__sub_spacing = sub_spacing
		self.__window_size = window_size


	def display_live(self):
		"""
		display_live

		Description:

		"""

		cv2.namedWindow("Disparity Map", cv2.WINDOW_NORMAL)
		cv2.moveWindow("Disparity Map", 40, 30)

		# Take images and display them live
		while(True):
			start_time1 = time.time()

			# Capture image and convert its colour accordingly
			ret1, im1 = self.__left_cap.read()
			im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)
			ret2, im2 = self.__right_cap.read()
			im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2RGB)

			print("Capture Time:\t{}".format(time.time() - start_time1))

			start_time = time.time()

			# Rectify the images
			lgray_rec, rgray_rec = self.__stereo_pro.rectify(self.__search_range, im1, im2)

			print("Rectify Images:\t{}".format(time.time() - start_time))

			start_time = time.time()
			
			# Find the disparity image
			disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing, self.__window_size, self.__search_range).astype(np.uint8)

			print("Disparity Mapping:\t{}".format(time.time() - start_time))

			start_time = time.time()

			# Display all the images
			cv2.imshow("Disparity Map", disp_map)
			cv2.waitKey(1)

			print("Display Time:\t{}".format(time.time() - start_time))

			print("Loop Time:{}\n\n".format(time.time() - start_time1))

		cv2.destroyAllWindows()



