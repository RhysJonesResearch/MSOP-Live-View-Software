"""
Author: Kyle Robert Newman
Date: 19 November 2020
Company: BRITElab & OncoRes

******************************************************************************
PROGRAM DESCRIPTION:
Setup display as an importable sub-module.
******************************************************************************

******************************************************************************
Version History
V1 -> 19 November 2020

******************************************************************************
"""

# Import necesary classes to shorten referencing from outside the package
from .colormaps import ColorMaps
from .live_capture import LiveCapture
from .live_capture_Rhys_edit import LiveCaptureRec
from .process_frame import ProcessFrame
from .multi_process_frame import MultiProcessFrame
#from .live_capture_Rhys_only_stress import LiveCaptureRec