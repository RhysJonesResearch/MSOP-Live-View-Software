import cv2
import time

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

from ximea import xiapi
from datetime import datetime
from ..logic import StereoImageProcessor
from .colormaps import ColorMaps
from ..utils import FileManager

# Required for record button on toolbar
import matplotlib
matplotlib.rcParams["toolbar"] = "toolmanager"
from matplotlib.backend_tools import ToolToggleBase
from matplotlib.backend_tools import ToolBase


class RecordButton(ToolToggleBase):
    description = 'Press to toggle recording, new toggles generate new files'
    name = "RecordButton"
    default_toggled = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.recording = 0 # flag variable
        #self._image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"
        #self.image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"

    def enable(self, *args):
        self.recording = 1
        #image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_stop.png"

    def disable(self, *args):
        self.recording = 0
        #image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"

class SaveImageButton(ToolBase):
    description = 'Press to save left and right images, stress and disparity maps in csv format'
    name = "SaveImageButton"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.TakeImage = 0 # flag variable

    def trigger(self, *args, **kwargs):
        self.TakeImage = 1

def handle_close(event):
    """
    handle_close

    Description:
    Handles when the matplotlib plot closes.
    """

    # Close the program
    exit()


class ProcessFrame:

    def __init__(
        self,
        stereo_pro: StereoImageProcessor,
        conn: dict,
        res: tuple,
        disp_model: list,
        search_range: list,
        sub_spacing: int,
        window_size: int,
        estimated_offset: list,
        layer_thickness: float,
        speckle_height: float):
        """
        __init__

        Description:

        Inputs:

        Outputs:

        """
        
        self.filedir = r'C:\Users\21705319\ Python Scripts\StereoOpticalPalpation\SOP_Data\Probe_9\Scans\20241110_22h30m28s'
        self.ImageNumber = 38
        
        self.RecordingNumber = 0
        self.PreviousRecordingNumber = 0
        self.res = res

        # Check that the input types are correct
        if(not isinstance(stereo_pro, StereoImageProcessor)):
            err = "'stereo_pro' must be a StereoImageProcessor object."
            raise TypeError(err)

        if(not isinstance(conn, dict)):
            err = "'conn' should be a dict instance."
            raise TypeError(err)

        if(not isinstance(res, tuple)):
            err = "'res' should be a tuple instance."
            raise TypeError(err)

        if(not isinstance(disp_model, list)):
            err = "'disp_model' should be a list instance."
            raise TypeError(err)

        if(not isinstance(search_range, list)):
            err = "'search_range' should be a list."
            raise TypeError(err)

        if(not isinstance(sub_spacing, int)):
            err = "'sub_spacing' should be a int."
            raise TypeError(err)

        if(not isinstance(window_size, int)):
            err = "'window_size' should be a int."
            raise TypeError(err)

        if(not isinstance(estimated_offset, list)):
            err = "'estimated_offset' should be a list."
            raise TypeError(err)

        if(not isinstance(layer_thickness, float)):
            err = "'layer_thickness' should be a float."
            raise TypeError(err)

        if(not isinstance(speckle_height, float)):
            err = "'speckle_height' should be a float."
            raise TypeError(err)

        # Save the stereo processor to a private field
        self.__stereo_pro = stereo_pro

        # Save the search range to a private field
        self.__search_range = search_range

        # Save sub_spacing and window_size to private fields
        self.__sub_spacing = sub_spacing
        self.__window_size = window_size

        # Save the estimated offset to a private field
        self.__estimated_offset = estimated_offset

        # Save the layer thickness and speckle hieght to a private fields
        self.__layer_thickness = layer_thickness
        self.__speckle_height = speckle_height
        self.__speckle_depth = self.__layer_thickness - self.__speckle_height

        # Define strain to stress parameters
        #self.__AA = 0.022479
        #self.__BB = 3.5987
        #self.__CC = -0.021772
        #self.__DD = 3.2488
        
        self.__A0 = 0
        self.__AA = -2.79709
        self.__BB = -3.52231
        self.__CC = 2.8478
        self.__DD = 1.98350

        # Save the displacement model to private instance variables
        self.__disp_model = disp_model

        # Obtain the desired colour map
        self.__parula_cmap = ColorMaps.create_parula()
        self.__parula_cmap.set_bad(color = "black")

        # Save the connection type
        self.__connt = conn["CONNECTION_TYPE"]


    def display_live(self, probe_id: int = None):
        """
        display_live

        Description:

        """
        # Setup output directory
        # Find the formatted time
        tt = datetime.today()
        ft = tt.strftime("%Y%m%d_%Hh%Mm%Ss")

        # save in same directory as new image
        ssdir = self.filedir + FileManager.get_slash()
        
        res = self.res
        res = self.res
        
        im1 = np.load(self.filedir + r'\im1_image_' +str(self.ImageNumber) + '.npy')
        im2 = np.load(self.filedir + r'\im2_image_' +str(self.ImageNumber) + '.npy')
        
        # Using cv2.split() to split channels of coloured image  
        #b,g,r = cv2.split(im1) 

        # Displaying Blue channel image 
        # Blue colour is highlighted the most 
        #cv2.imshow("subtract median g", cv2.medianBlur(g, 7) - g)                          # trying to find a way of isolating particles from background.
        #cv2.imshow("median g", cv2.medianBlur(g, 7)) 

        # Displaying Green channel image 
        # Green colour is highlighted the most 
        #cv2.imshow("g", g)

        # Displaying Red channel image 
        # Red colour is highlighted the most 
        #cv2.imshow("Model Red Image", b) 

        proc_start = time.time()

        # Rectify the images
        lgray_rec, rgray_rec = self.__stereo_pro.rectify(
                                        self.__search_range, im1, im2) # insert artifact after this to check fov's

        # Find the disparity image
        disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing,
                                    self.__window_size, self.__search_range)

        # Cut out noise
        du = np.mean(disp_map)
        dstd = np.std(disp_map)
        idx_x, idx_y = np.where(2.0*dstd < np.abs(disp_map-du))    # THIS WAS ORIGINALLY JUST BEFORE DISPLAY
        #idx_x, idx_y = np.where(10 < np.abs(disp_map-du))
        disp_map = disp_map.astype(np.float)
        #disp_map[idx_x, idx_y] = np.nan

        # Convert disparity to displacement
        #dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1]
        
        m = np.load(r'C:\Users\21705319\ Python Scripts\StereoOpticalPalpation\SOP_Data\Probe_9\Scans\20241105_15h12m33s'+r'\m_image'+'.npy')
        c = np.load(r'C:\Users\21705319\ Python Scripts\StereoOpticalPalpation\SOP_Data\Probe_9\Scans\20241105_15h12m33s'+r'\c_image'+'.npy')
        
        dist_map = m[0:disp_map.shape[0],0:disp_map.shape[1]] * disp_map + c[0:disp_map.shape[0],0:disp_map.shape[1]] # pixel by pixel map intended for use with specific config - post settings, need to recalculate for any changes

        # Convert displacement to strain
        strain_map = 1 - (dist_map * (1 + self.__speckle_height 
                        / self.__speckle_depth)) / (self.__layer_thickness)

        # Convert strain to stress (in kPa)
        stress_map = self.__A0 + (self.__AA * np.exp(self.__BB * strain_map) +
                            self.__CC * np.exp(self.__DD * strain_map))

        print("Process Time:\t{}".format(time.time() - proc_start))

        # Initialise the figure window
        fig, axes = plt.subplots(3, 2)
        fig.canvas.mpl_connect("close_event", handle_close)
        plt.subplots_adjust(bottom = 0.05, top = 0.9, left = 0.05,
                                                            right = 0.96)
        fig.suptitle("SOP Live Display", fontsize = 14)

        # Initialize each axis
        axes[0, 0].set_title("Left Image", fontsize = 10)
        axes[0, 0].set_xticklabels([])
        axes[0, 0].set_yticklabels([])
        axes[0, 1].set_title("Right Image", fontsize = 10)
        axes[0, 1].set_xticklabels([])
        axes[0, 1].set_yticklabels([])
        axes[1, 0].set_title("Rectified Left Image", fontsize = 10)
        axes[1, 0].set_xticklabels([])
        axes[1, 0].set_yticklabels([])
        axes[1, 1].set_title("Rectified Right Image", fontsize = 10)
        axes[1, 1].set_xticklabels([])
        axes[1, 1].set_yticklabels([])
        axes[2, 0].set_title("Disparity Map", fontsize = 10)
        axes[2, 0].set_xticklabels([])
        axes[2, 0].set_yticklabels([])
        axes[2, 1].set_title("Stress Map", fontsize = 10)
        axes[2, 1].set_xticklabels([])
        axes[2, 1].set_yticklabels([])

        # Add Button(s) to save and stop saving video
        tm = fig.canvas.manager.toolmanager
        tm.add_tool("RecordButton", RecordButton)
        fig.canvas.manager.toolbar.add_tool(tm.get_tool("RecordButton"), "toolgroup")
        
        # Add Button(s) to save images
        tm = fig.canvas.manager.toolmanager
        tm.add_tool("SaveImageButton", SaveImageButton)
        fig.canvas.manager.toolbar.add_tool(tm.get_tool("SaveImageButton"), "toolgroup")

        # Show the raw images
        image_show1 = axes[0, 0].imshow(im1, "gray")
        image_show2 = axes[0, 1].imshow(im2, "gray")

        # Find the ROIs
        left_ROI, right_ROI = self.__stereo_pro.get_rois()

        # Create the rectangles to draw onto the images
        ly = left_ROI['top_edge']
        lx = left_ROI['left_edge']
        ldy = left_ROI['bottom_edge'] - left_ROI['top_edge']
        ldx = left_ROI['right_edge'] - left_ROI['left_edge']
        rect1 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')
        ry = right_ROI['top_edge']
        rx = right_ROI['left_edge']
        rdy = right_ROI['bottom_edge'] - right_ROI['top_edge']
        rdx = right_ROI['right_edge'] - right_ROI['left_edge']
        rect2 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')

        # Add the rectangles to the image
        axes[0, 0].add_patch(rect1)
        axes[0, 1].add_patch(rect2)

        print(left_ROI)
        print(right_ROI)

        # Display the rectified images
        image_show3 = axes[1, 0].imshow(lgray_rec, cmap = "gray", vmin = 0, vmax = 255)
        
        # Create the rectangles to draw onto the images
        ly = self.__window_size/2
        lx = self.__window_size/2
        ldy = left_ROI['bottom_edge'] - left_ROI['top_edge'] - self.__window_size
        ldx = left_ROI['right_edge'] - left_ROI['left_edge'] - self.__window_size
        rect3 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')

        print([ldy,ldx])

        # Add the rectangles to the image
        axes[1, 0].add_patch(rect3)
        
        # Display the rectified images
        image_show4 = axes[1, 1].imshow(rgray_rec, cmap = "gray", vmin = 0, vmax = 255)
        
        # Create the rectangles to draw onto the images
        ry = self.__window_size/2
        rx = self.__window_size/2
        rdy = right_ROI['bottom_edge'] - right_ROI['top_edge'] - self.__window_size
        rdx = right_ROI['right_edge'] - right_ROI['left_edge'] - self.__window_size
        rect4 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')

        # Add the rectangles to the image
        #axes[1, 1].add_patch(rect4)

        # Display the disparity and stress images
        image_show5 = axes[2, 0].imshow(disp_map, cmap = self.__parula_cmap)
        image_show6 = axes[2, 1].imshow(stress_map, cmap = self.__parula_cmap)
        fig.colorbar(image_show5, ax = axes[2, 0])
        fig.colorbar(image_show6, ax = axes[2, 1])

        # Interactive mode on
        plt.ion()

        # Find the disparity map mean and standard deviation
        su = np.nanmean(stress_map)
        sstd = np.nanstd(stress_map)
        eu = np.nanmean(strain_map)
        estd = np.nanstd(strain_map)
        diu = np.nanmean(dist_map)
        distd = np.nanstd(dist_map)

        print(np.shape(disp_map))

        # Take images and display them live
        while(True):
            # Display all the images
            image_show1.set_data(im1)
            image_show2.set_data(im2)
            image_show3.set_data(lgray_rec)
            image_show4.set_data(rgray_rec)
            image_show5.set_data(disp_map)
            image_show6.set_data(stress_map)
            plt.pause(0.0000000001)
            
            if (tm.tools["SaveImageButton"].TakeImage == 1):
                np.save(ssdir + "im1_image_" +str(self.ImageNumber) + "_reproc", im1)
                np.save(ssdir + "im2_image_" +str(self.ImageNumber) + "_reproc", im2)
                np.save(ssdir + "disp_map_image_" +str(self.ImageNumber) + "_reproc", disp_map)
                np.save(ssdir + "dist_map_image_" +str(self.ImageNumber) + "_reproc", dist_map)
                np.save(ssdir + "strain_map_image_" +str(self.ImageNumber) + "_reproc", strain_map)
                np.save(ssdir + "stress_map_image_" +str(self.ImageNumber) + "_reproc", stress_map)
                np.save(ssdir + "im1_ROI_" +str(self.ImageNumber) + "_reproc", left_ROI)
                np.save(ssdir + "im2_ROI_" +str(self.ImageNumber) + "_reproc", right_ROI)
                tm.tools["SaveImageButton"].TakeImage = 0
            

        plt.ioff()
        plt.show()




