import cv2
import time

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

from ximea import xiapi
from datetime import datetime
from ..logic import StereoImageProcessor
from .colormaps import ColorMaps
from ..utils import FileManager

# Required for record button on toolbar
import matplotlib
matplotlib.rcParams["toolbar"] = "toolmanager"
from matplotlib.backend_tools import ToolToggleBase
from matplotlib.backend_tools import ToolBase

from pypylon import pylon


class RecordButton(ToolToggleBase):
    description = 'Press to toggle recording, new toggles generate new files'
    name = "RecordButton"
    default_toggled = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.recording = 0 # flag variable
        #self._image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"
        #self.image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"

    def enable(self, *args):
        self.recording = 1
        #image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_stop.png"

    def disable(self, *args):
        self.recording = 0
        #image = r"C:\Users\21705319\ Python Scripts\SOP_Code_Rhys_edit\player_record.png"

class SaveImageButton(ToolBase):
    description = 'Press to save left and right images, stress and disparity maps in csv format'
    name = "SaveImageButton"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.TakeImage = 0 # flag variable

    def trigger(self, *args, **kwargs):
        self.TakeImage = 1

def handle_close(event):
    """
    handle_close

    Description:
    Handles when the matplotlib plot closes.
    """

    # Close the program
    exit()


class LiveCaptureRec:                                              # NEXT STEP IS TO IMPLEMENT THREADED FRAME CAPTURE AND SEPERATE THREADED FRAME DISPLAY, maybe using flagging to tell each thread when a new thing exists?
    """
    LiveCaptureRec

    Description:

    """

    def __init__(
        self,
        stereo_pro: StereoImageProcessor,
        conn: dict,
        res: tuple,
        disp_model: list,
        search_range: list,
        sub_spacing: int,
        window_size: int,
        estimated_offset: list,
        layer_thickness: float,
        speckle_height: float):
        """
        __init__

        Description:

        Inputs:

        Outputs:

        """
        self.RecordingNumber = 0
        self.PreviousRecordingNumber = 0
        self.ImageNumber = 0
        self.res = res

        # Check that the input types are correct
        if(not isinstance(stereo_pro, StereoImageProcessor)):
            err = "'stereo_pro' must be a StereoImageProcessor object."
            raise TypeError(err)

        if(not isinstance(conn, dict)):
            err = "'conn' should be a dict instance."
            raise TypeError(err)

        if(not isinstance(res, tuple)):
            err = "'res' should be a tuple instance."
            raise TypeError(err)

        if(not isinstance(disp_model, list)):
            err = "'disp_model' should be a list instance."
            raise TypeError(err)

        if(not isinstance(search_range, list)):
            err = "'search_range' should be a list."
            raise TypeError(err)

        if(not isinstance(sub_spacing, int)):
            err = "'sub_spacing' should be a int."
            raise TypeError(err)

        if(not isinstance(window_size, int)):
            err = "'window_size' should be a int."
            raise TypeError(err)

        if(not isinstance(estimated_offset, list)):
            err = "'estimated_offset' should be a list."
            raise TypeError(err)

        if(not isinstance(layer_thickness, float)):
            err = "'layer_thickness' should be a float."
            raise TypeError(err)

        if(not isinstance(speckle_height, float)):
            err = "'speckle_height' should be a float."
            raise TypeError(err)

        # Check the connection type
        if(conn["CONNECTION_TYPE"] == 5):
            # 1. Connect to the first available Basler camera
            self.camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())
            self.camera.Open()
            # Optional: Print camera model to verify connection
            print("Connected to:", self.camera.GetDeviceInfo().GetModelName())
            # 2. Configure the image format converter for OpenCV (BGR)
            self.converter = pylon.ImageFormatConverter()
            self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
            self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned
            # 3. settings
            self.camera.ExposureAuto.Value = "Off"
            self.camera.ExposureTime.Value = 100000.0  # In microseconds (10,000 us = 10 ms)
            #self.camera.ExposureTime.Value = 500000.0  # In microseconds (10,000 us = 10 ms)
            self.camera.GainAuto.Value = "Off"
            self.camera.Gain.Value = 5.0  # In dB
            #self.camera.Gain.Value = 0.0  # In dB
            self.camera.Gamma.Value = 1.5
            #self.camera.Gamma.Value = 2.5

            # --- 4. Resolution / Region of Interest (ROI) ---
            # Must be set BEFORE StartGrabbing()
            self.camera.OffsetX.Value = 0
            self.camera.OffsetY.Value = 0
            self.camera.Width.Value = 3304 # needs to be divisble by 8
            self.camera.Height.Value = 1300
            self.camera.OffsetX.Value = 250
            self.camera.OffsetY.Value = 290
            
            # 4. Start grabbing frames (LatestImageOnly prevents lag/buffer buildup)
            self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
        elif(conn["CONNECTION_TYPE"] == 1):
            # Initialise a video capture for both devices
            self.__left_cap = cv2.VideoCapture(int(conn["LEFT_PORT"]))
            self.__right_cap = cv2.VideoCapture(int(conn["RIGHT_PORT"]))
        elif(conn["CONNECTION_TYPE"] == 0):
            lip = "http://" + conn["LEFT_IP"] + ":" + conn["LEFT_PORT"]
            rip = "http://" + conn["RIGHT_IP"] + ":" + conn["RIGHT_PORT"]
            self.__left_cap = cv2.VideoCapture(lip)
            self.__right_cap = cv2.VideoCapture(rip)
        elif(conn["CONNECTION_TYPE"] == 2):
            # Open the benchtop cameras
            self.__left_cap = xiapi.Camera()
            self.__left_cap.open_device_by_SN(conn["LEFT_PORT"])
            self.__left_cap.set_param('auto_wb', True)
            self.__left_cap.set_exposure(150000)
            self.__right_cap = xiapi.Camera()
            self.__right_cap.open_device_by_SN(conn["RIGHT_PORT"])
            self.__right_cap.set_param('auto_wb', True)
            self.__right_cap.set_exposure(150000)

            # Set the colour scheme output and start the acquisition
            self.__left_cap.set_imgdataformat("XI_RGB24")
            self.__right_cap.set_imgdataformat("XI_RGB24")
            self.__left_cap.start_acquisition()
            self.__right_cap.start_acquisition()
        elif(conn["CONNECTION_TYPE"] == 3):                                                   # MAKING CHANGES HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            #bothip = "http://" + conn["BOTH_IP"] + ":" + conn["BOTH_PORT"]
            bothip = conn["LEFT_IP"]
            print(bothip)
            self.__both_cap = cv2.VideoCapture(bothip) #, cv2.CAP_DSHOW)
        elif(conn["CONNECTION_TYPE"] == 4):                                                   # MAKING CHANGES HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            self.__both_cap = cv2.VideoCapture(int(conn["LEFT_PORT"]), cv2.CAP_DSHOW)
        else:
            err = "Invalid connection type encountered."
            raise ValueError(err)

        # # Ben's probe
        # self.__left_cap = cv2.VideoCapture(1)
        # self.__right_cap = cv2.VideoCapture(0)

        # Aiden's probe
        # self.__right_cap = cv2.VideoCapture("http://192.168.0.1:8196/")
        # self.__left_cap = cv2.VideoCapture("http://192.168.0.2:8197/")

        # Change the resolution of the handheld systems
        if(conn["CONNECTION_TYPE"] != 2 and conn["CONNECTION_TYPE"] != 3 and conn["CONNECTION_TYPE"] != 4 and conn["CONNECTION_TYPE"] != 5):
            self.__left_cap.set(3, res[0])
            self.__left_cap.set(4, res[1])
            self.__right_cap.set(3, res[0])
            self.__right_cap.set(4, res[1])
        if(conn["CONNECTION_TYPE"] == 3 or conn["CONNECTION_TYPE"] == 4):
            self.__both_cap.set(3, res[0]*2)
            self.__both_cap.set(4, res[1])

        # Save the stereo processor to a private field
        self.__stereo_pro = stereo_pro

        # Save the search range to a private field
        self.__search_range = search_range

        # Save sub_spacing and window_size to private fields
        self.__sub_spacing = sub_spacing
        self.__window_size = window_size

        # Save the estimated offset to a private field
        self.__estimated_offset = estimated_offset

        # Save the layer thickness and speckle hieght to a private fields
        self.__layer_thickness = layer_thickness
        self.__speckle_height = speckle_height
        self.__speckle_depth = self.__layer_thickness - self.__speckle_height

        # Define strain to stress parameters
        #self.__AA = 0.022479
        #self.__BB = 3.5987
        #self.__CC = -0.021772
        #self.__DD = 3.2488
        
        self.__A0 = 0
        self.__AA = -2.79709
        self.__BB = -3.52231
        self.__CC = 2.8478
        self.__DD = 1.98350

        # Save the displacement model to private instance variables
        self.__disp_model = disp_model

        # Obtain the desired colour map
        self.__parula_cmap = ColorMaps.create_parula()
        self.__parula_cmap.set_bad(color = "black")

        # Save the connection type
        self.__connt = conn["CONNECTION_TYPE"]


    def display_live(self, probe_id: int = None):
        """
        display_live

        Description:

        """
        # Setup output directory
        # Find the formatted time
        tt = datetime.today()
        ft = tt.strftime("%Y%m%d_%Hh%Mm%Ss")
        
        res = self.res
        
        # Capture images and convert the colour accordingly
        im = None; im1 = None; im2 = None; image_show1 = None; image_show2 = None
        if(self.__connt == 5):
            if 0:
                try:
                    while self.camera.IsGrabbing():
                        # Wait up to 5000 ms for a frame
                        grabResult = self.camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                        if grabResult.GrabSucceeded():
                            # Convert to OpenCV BGR NumPy array
                            image = self.converter.Convert(grabResult)
                            img = image.GetArray()
                            #img = img[:, :, 1] # take green channel only
                            # Resize for display if 4K (3840x2160) is too large for your screen
                            #display_img = cv2.resize(img, (1280, 720))
                            display_img = cv2.resize(img, (int(self.camera.Width.Value/4), int(self.camera.Height.Value/4)))
                            cv2.imshow("Basler daA3840-45uc", display_img)
                            # Press 'q' or ESC to exit
                            key = cv2.waitKey(1) & 0xFF
                            if key == ord("q") or key == 27:
                                break
                        grabResult.Release()
                except:
                    print("CameraAcquisistionError")
            else:
                try:
                    # Wait up to 5000 ms for a frame
                    grabResult = self.camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                    if grabResult.GrabSucceeded():
                        # Convert to OpenCV BGR NumPy array
                        image = self.converter.Convert(grabResult)
                        img = image.GetArray()
                        #img = img[:, :, 1] # take green channel only
                        # Resize for display if 4K (3840x2160) is too large for your screen
                        #display_img = cv2.resize(img, (1280, 720))
                        display_img = cv2.resize(img, (int(self.camera.Width.Value/4), int(self.camera.Height.Value/4)))
                    grabResult.Release()
                except:
                    print("CameraAcquisistionError")
                print(np.shape(display_img))
                res = [int(self.camera.Width.Value/8), int(self.camera.Height.Value/4)] # set res
                im1 = display_img[:,0:int(res[0])]
                im2 = display_img[:,int(res[0]):int(res[0]*2)]
        elif(self.__connt == 3 or self.__connt == 4):                                                                  # MAKING CHANGES HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            ret, im = self.__both_cap.read()
            #im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
            print(np.shape(im))
            im1 = im[:,0:int(res[0])]
            im2 = im[:,int(res[0]):int(res[0]*2)]
        elif(self.__connt != 2):
            ret1, im1 = self.__left_cap.read()
            im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)
            ret2, im2 = self.__right_cap.read()
            im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2RGB)
        else:
            # Read in images
            xi_im1 = xiapi.Image()
            xi_im2 = xiapi.Image()
            self.__left_cap.get_image(xi_im1)
            self.__right_cap.get_image(xi_im2)
            raw_im1 = list(xi_im1.get_image_data_raw())
            raw_im2 = list(xi_im2.get_image_data_raw())
            im1 = np.array(raw_im1).reshape((3680, 4896, 3)).astype(np.uint8)
            im2 = np.array(raw_im2).reshape((3680, 4896, 3)).astype(np.uint8)

        #while 1:
        #    cv2.imshow("Test", im1[:,:,1])
        #    # Press 'q' or ESC to exit
        #    key = cv2.waitKey(1) & 0xFF
        #    if key == ord("q") or key == 27:
        #        break
        #cv2.destroyAllWindows()

        # Rectify the images
        lgray_rec, rgray_rec = self.__stereo_pro.rectify(
                                        self.__search_range, im1, im2) # now only takes green channel, no undistortion or rectification

        # Find the disparity image
        DispAtWindow = np.load(r'C:\Users\SOP Software\Documents\StereoOpticalPalpation\SOP_DATA\Probe_2026\Scans\LayerAtWindow'+r'\disp_int.npy')
        disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing, self.__window_size, self.__search_range) - DispAtWindow

        # Convert disparity to displacement
        dist_map = self.__disp_model[0] * (disp_map) + self.__disp_model[1]
        

        # Convert displacement to strain
        strain_map = 1 - (dist_map * (1 + self.__speckle_height 
                        / self.__speckle_depth)) / (self.__layer_thickness)

        # Convert strain to stress (in kPa)
        stress_map = self.__A0 + (self.__AA * np.exp(self.__BB * strain_map) +
                            self.__CC * np.exp(self.__DD * strain_map))

        # Benchtop system does not support live image display
        # if(self.__connt == 2):
        if(probe_id is None):
            err = "'probe_id' must be specified for the benchtop system."
            raise RuntimeError(err)

        if(self.__connt == 2 ):

            # Draw the ROI on the images
            im1_rect, im2_rect = self.__stereo_pro.rectify(None, im1, im2)
            lroi, rroi = self.__stereo_pro.get_rois()
            ltl = (lroi["left_edge"], lroi["top_edge"])
            lbr = (lroi["right_edge"], lroi["bottom_edge"])
            rtl = (rroi["left_edge"], rroi["top_edge"])
            rbr = (rroi["right_edge"], rroi["bottom_edge"])
            im1_rect = cv2.rectangle(im1_rect, ltl, lbr, (0, 0, 255), 6)
            im2_rect = cv2.rectangle(im2_rect, rtl, rbr, (0, 0, 255), 6)

            # Save the images
            cv2.imwrite(ssdir + "left_img_{}.jpg".format(ft), im1)
            cv2.imwrite(ssdir + "right_img_{}.jpg".format(ft), im2)
            cv2.imwrite(ssdir + "left_rect_full_{}.jpg".format(ft), im1_rect)
            cv2.imwrite(ssdir + "right_rect_full_{}.jpg".format(ft), im2_rect)
            cv2.imwrite(ssdir + "left_rect_{}.jpg".format(ft), lgray_rec)
            cv2.imwrite(ssdir + "right_rect_{}.jpg".format(ft), rgray_rec)
            cv2.imwrite(ssdir + "disparity_map_{}.jpg".format(ft), disp_map)
            cv2.imwrite(ssdir + "displacement_map_{}.jpg".format(ft), dist_map)
            cv2.imwrite(ssdir + "strain_map_{}.jpg".format(ft), strain_map)
            cv2.imwrite(ssdir + "stress_map_{}.jpg".format(ft), stress_map)

            # Save the raw data
            np.save(ssdir + "left_img_{}.npy".format(ft), im1)
            np.save(ssdir + "right_img_{}.npy".format(ft), im2)
            np.save(ssdir + "left_rect_{}.npy".format(ft), lgray_rec)
            np.save(ssdir + "right_rect_{}.npy".format(ft), rgray_rec)
            np.save(ssdir + "disparity_map_{}.npy".format(ft), disp_map)
            np.save(ssdir + "displacement_map_{}.npy".format(ft), dist_map)
            np.save(ssdir + "strain_map_{}.npy".format(ft), strain_map)
            np.save(ssdir + "stress_map_{}.npy".format(ft), stress_map)

            # Process the disparity map
            du = np.mean(disp_map)
            dstd = np.std(disp_map)
            idx_x, idx_y = np.where(1.5*dstd < np.abs(disp_map-du))
            disp_map = disp_map.astype(np.float64)
            disp_map[idx_x, idx_y] = np.nan

            # Display the disparity at the center pixel
            cu = disp_map.shape[0] // 2
            cv = disp_map.shape[1] // 2
            print("Center Location:\t(cu: {}, cv: {})".format(cu, cv))
            print("Disparity at Center:\t{}".format(disp_map[cu, cv]))

            # Show the disparity map
            plt.imshow(disp_map, cmap = self.__parula_cmap, clim = [du-1.5*dstd, du+1.5*dstd])
            plt.title("Disparity Map")
            plt.show()

            exit()

        # Initialise the figure window
        fig, axes = plt.subplots(2, 2)
        fig.canvas.mpl_connect("close_event", handle_close)
        plt.subplots_adjust(bottom = 0.05, top = 0.9, left = 0.05,
                                                            right = 0.96)
        fig.suptitle("SOP Live Display", fontsize = 14)

        # Initialize each axis
        axes[0, 0].set_title("Left Image", fontsize = 10)
        axes[0, 0].set_xticklabels([])
        axes[0, 0].set_yticklabels([])
        axes[0, 1].set_title("Right Image", fontsize = 10)
        axes[0, 1].set_xticklabels([])
        axes[0, 1].set_yticklabels([])
        #axes[1, 0].set_title("Left ROI", fontsize = 10)
        #axes[1, 0].set_xticklabels([])
        #axes[1, 0].set_yticklabels([])
        #axes[1, 1].set_title("Right ROI", fontsize = 10)
        #axes[1, 1].set_xticklabels([])
        #axes[1, 1].set_yticklabels([])
        axes[1, 0].set_title("Disparity Map (pix)", fontsize = 10)
        axes[1, 0].set_xticklabels([])
        axes[1, 0].set_yticklabels([])
        axes[1, 1].set_title("Stress Map (kPa)", fontsize = 10)
        axes[1, 1].set_xticklabels([])
        axes[1, 1].set_yticklabels([])

        # Add Button(s) to save and stop saving video
        tm = fig.canvas.manager.toolmanager
        tm.add_tool("RecordButton", RecordButton)
        fig.canvas.manager.toolbar.add_tool(tm.get_tool("RecordButton"), "toolgroup")
        
        # Add Button(s) to save images
        tm = fig.canvas.manager.toolmanager
        tm.add_tool("SaveImageButton", SaveImageButton)
        fig.canvas.manager.toolbar.add_tool(tm.get_tool("SaveImageButton"), "toolgroup")

        # Show the raw images
        image_show1 = axes[0, 0].imshow(im1)
        image_show2 = axes[0, 1].imshow(im2)

        # Find the ROIs
        left_ROI, right_ROI = self.__stereo_pro.get_rois()

        # Create the rectangles to draw onto the images
        ly = left_ROI['top_edge']
        lx = left_ROI['left_edge']
        ldy = left_ROI['bottom_edge'] - left_ROI['top_edge']
        ldx = left_ROI['right_edge'] - left_ROI['left_edge']
        rect1 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')
        ry = right_ROI['top_edge']
        rx = right_ROI['left_edge']
        rdy = right_ROI['bottom_edge'] - right_ROI['top_edge']
        rdx = right_ROI['right_edge'] - right_ROI['left_edge']
        rect2 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')

        # Add the rectangles to the image
        axes[0, 0].add_patch(rect1)
        axes[0, 1].add_patch(rect2)

        # Find the disparity map mean and standard deviation
        du = np.mean(disp_map)
        dstd = np.std(disp_map)

        # Cut out noise
        idx_x, idx_y = np.where(1.5*dstd < np.abs(disp_map-du))
        disp_map = disp_map.astype(np.float64)
        disp_map[idx_x, idx_y] = np.nan

        # Display the rectified images
        #image_show3 = axes[1, 0].imshow(lgray_rec, cmap = "gray", vmin = 0, vmax = 255)
        #image_show4 = axes[1, 1].imshow(rgray_rec, cmap = "gray", vmin = 0, vmax = 255)
        image_show5 = axes[1, 0].imshow(disp_map, cmap = self.__parula_cmap, clim = [0,20])
        image_show6 = axes[1, 1].imshow(stress_map, cmap = self.__parula_cmap, clim=[0,25])
        #fig.colorbar(image_show5, ax = axes[1, 0])
        #fig.colorbar(image_show6, ax = axes[1, 1])

        # Interactive mode on
        #plt.ion()
        #plt.show(block=False)
        fig.canvas.draw()
        fig.canvas.flush_events()
        
        # Set animated=True so Matplotlib excludes them from the static background
        image_show1 = axes[0, 0].imshow(im1, animated=True)
        image_show2 = axes[0, 1].imshow(im2, animated=True)
        # (keep your rectangle patches and ROI setup here)
        #image_show3 = axes[1, 0].imshow(lgray_rec, cmap="gray", vmin=0, vmax=255, animated=True)
        #image_show4 = axes[1, 1].imshow(rgray_rec, cmap="gray", vmin=0, vmax=255, animated=True)
        image_show5 = axes[1, 0].imshow(disp_map, cmap=self.__parula_cmap, clim=[0,20]) #, animated=True)
        image_show6 = axes[1, 1].imshow(stress_map, cmap=self.__parula_cmap, clim=[0,25]) #, animated=True)

        fig.colorbar(image_show5, ax=axes[1, 0])
        fig.colorbar(image_show6, ax=axes[1, 1])

        plt.ion()
        plt.show(block=False)
        plt.pause(0.1) # Give the GUI window a moment to render completely

        # Capture the static background (titles, borders, colorbars)
        bg = fig.canvas.copy_from_bbox(fig.bbox)
        

        # Take images and display them live
        av_cap_time = 0
        av_proc_time = 0
        n = 0
        while(True):
            start_time1 = time.time()

            # Capture image and convert its colour accordingly
            if(self.__connt == 5):
                try:
                    # Wait up to 5000 ms for a frame
                    grabResult = self.camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                    if grabResult.GrabSucceeded():
                        # Convert to OpenCV BGR NumPy array
                        image = self.converter.Convert(grabResult)
                        img = image.GetArray()
                        #img = img[:, :, 1] # take green channel only
                        # Resize for display if 4K (3840x2160) is too large for your screen
                        #display_img = cv2.resize(img, (1280, 720))
                        display_img = cv2.resize(img, (int(self.camera.Width.Value/4), int(self.camera.Height.Value/4)))
                    grabResult.Release()
                except:
                    print("CameraAcquisistionError")
                print(np.shape(display_img))
                res = [int(self.camera.Width.Value/8), int(self.camera.Height.Value/4)] # set res
                im1 = display_img[:,0:int(res[0])]
                im2 = display_img[:,int(res[0]):int(res[0]*2)]
            elif(self.__connt == 3 or self.__connt == 4):                                                                  # MAKING CHANGES HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                ret, im = self.__both_cap.read()
                im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
                #im = cv2.cvtColor(im, cv2.COLOR_RGB2BGR)
                im1 = im[:,0:int(res[0])]
                im2 = im[:,int(res[0]):int(res[0]*2)]
            elif(self.__connt != 2):
                ret1, im1 = self.__left_cap.read()
                im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)
                ret2, im2 = self.__right_cap.read()
                im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2RGB)
            else:
                # Read in images
                xi_im1 = xiapi.Image()
                xi_im2 = xiapi.Image()
                self.__left_cap.get_image(xi_im1)
                self.__right_cap.get_image(xi_im2)
                raw_im1 = list(xi_im1.get_image_data_raw())
                raw_im2 = list(xi_im2.get_image_data_raw())
                im1 = np.array(raw_im1).reshape((3680, 4896, 3)).astype(np.uint8)
                im2 = np.array(raw_im2).reshape((3680, 4896, 3)).astype(np.uint8)

            print("Capture Time:\t{}".format(time.time() - start_time1))
            av_cap_time = av_cap_time + time.time() - start_time1
            n = n+1
            
            print("Av_cap_time")
            print(av_cap_time / n)

            start_time = time.time()
            proc_start = time.time()

            # Rectify the images
            lgray_rec, rgray_rec = self.__stereo_pro.rectify(
                                                self.__search_range, im1, im2)

            #print("Rectify Images:\t{}".format(time.time() - start_time))

            start_time = time.time()

            # Find the disparity image
            disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing, self.__window_size, self.__search_range) - DispAtWindow
            
            # Cut out noise
            du = np.mean(disp_map)
            dstd = np.std(disp_map)
            #idx_x, idx_y = np.where(2.0*dstd < np.abs(disp_map-du))    # THIS IS ORIGINALLY JUST BEFORE DISPLAY
            #idx_x, idx_y = np.where(20 < np.abs(disp_map-du))
            disp_map = disp_map.astype(np.float64)
            #disp_map[idx_x, idx_y] = np.nan

            # Convert disparity to displacement
            dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1]
            
            #if m.shape[0] > disp_map.shape[0]:
            #    #print('THIS IS WRONG YOU SHOULD PROCESS A NEW M AND C')
            #    dist_map = m[0:disp_map.shape[0],0:disp_map.shape[1]] * disp_map + c[0:disp_map.shape[0],0:disp_map.shape[1]] # THIS IS WRONG YOU SHOULD PROCESS A NEW M AND C
            #elif m.shape[0] < disp_map.shape[0]:
            #    #print('THIS IS WRONG YOU SHOULD PROCESS A NEW M AND C')
            #    dist_map = m * disp_map[0:m.shape[0],0:m.shape[1]] + c # THIS IS WRONG YOU SHOULD PROCESS A NEW M AND C
            #else:
            #    dist_map = m * disp_map + c # pixel by pixel map intended for use with specific config - post settings, need to recalculate for any changes

            # Convert displacement to strain
            strain_map = 1 - ((dist_map) * (1 + self.__speckle_height /                            # defined 0 as outside window boundary in disp_model
                            self.__speckle_depth)) / (self.__layer_thickness)

            # Convert strain to stress
            stress_map = self.__A0+(self.__AA * np.exp(self.__BB * strain_map) +
                                self.__CC * np.exp(self.__DD * strain_map))

            #print("Disparity Mapping:\t{}".format(time.time() - start_time))

            # Find the disparity map mean and standard deviation
            su = np.nanmean(stress_map)
            sstd = np.nanstd(stress_map)
            eu = np.nanmean(strain_map)
            estd = np.nanstd(strain_map)
            diu = np.nanmean(dist_map)
            distd = np.nanstd(dist_map)

            start_time = time.time()

            av_proc_time = av_proc_time + time.time() - proc_start
            print("Av_proc_time")
            print(av_proc_time / n)

            start_time = time.time()

            # Display all the images
            #image_show5.set_clim([du-2.0*dstd, du+2.0*dstd])
            #image_show6.set_clim([su-2.0*sstd, su+2.0*sstd])
            #image_show1.set_data(im1)
            #image_show2.set_data(im2)
            #image_show3.set_data(lgray_rec)
            #image_show4.set_data(rgray_rec)
            #image_show5.set_data(disp_map)
            #image_show6.set_data(stress_map)
            
            #fig.canvas.draw_idle()
            #fig.canvas.flush_events()
            
            # 1. Restore the cached static background
            fig.canvas.restore_region(bg)

            # 2. Update the data
            image_show5.set_clim([0,10]) #[du-2.0*dstd, du+2.0*dstd])
            image_show6.set_clim([0,15]) #[su-2.0*sstd, su+2.0*sstd])
            image_show1.set_data(im1)
            image_show2.set_data(im2)
            #image_show3.set_data(lgray_rec)
            #image_show4.set_data(rgray_rec)
            image_show5.set_data(14-disp_map)
            image_show6.set_data(stress_map)

            # 3. Redraw ONLY the image artists (and the ROI boxes so they stay on top)
            for ax, artist in [
                (axes[0, 0], image_show1), (axes[0, 0], rect1),
                (axes[0, 1], image_show2), (axes[0, 1], rect2),
                #(axes[1, 0], image_show3), (axes[1, 1], image_show4),
                (axes[1, 0], image_show5), (axes[1, 1], image_show6),
            ]:
                ax.draw_artist(artist)

            # 4. Blit the updated pixels to the screen and process button clicks
            fig.canvas.blit(fig.bbox)
            fig.canvas.flush_events()

            
            if (tm.tools["SaveImageButton"].TakeImage == 1):
                # Find the probe's scan directory and make it if it doesn't exist
                sdir = FileManager.get_scans_dir(probe_id)
                ssdir = sdir + ft + FileManager.get_slash()
                FileManager.mkdir(sdir)
                FileManager.mkdir(ssdir)
                self.ImageNumber = self.ImageNumber + 1
                np.save(ssdir + "im1_image_" +str(self.ImageNumber), im1)
                np.save(ssdir + "im2_image_" +str(self.ImageNumber), im2)
                np.save(ssdir + "disp_map_image_" +str(self.ImageNumber), disp_map)
                np.save(ssdir + "dist_map_image_" +str(self.ImageNumber), dist_map)
                np.save(ssdir + "strain_map_image_" +str(self.ImageNumber), strain_map)
                np.save(ssdir + "stress_map_image_" +str(self.ImageNumber), stress_map)
                np.save(ssdir + "im1_ROI_" +str(self.ImageNumber), left_ROI)
                np.save(ssdir + "im2_ROI_" +str(self.ImageNumber), right_ROI)
                #np.savetxt(ssdir + "im1_image_" +str(self.ImageNumber) + ".txt", im1.reshape(6220800), delimiter=',')
                #np.savetxt(ssdir + "im2_image_" +str(self.ImageNumber) + ".txt", im2.reshape(6220800), delimiter=',')
                #np.savetxt(ssdir + "disp_map_image_" +str(self.ImageNumber) + ".txt", disp_map, delimiter=',')
                #np.savetxt(ssdir + "stress_map_image_" +str(self.ImageNumber) + ".txt", stress_map, delimiter=',')
                tm.tools["SaveImageButton"].TakeImage = 0
            
            if (tm.tools["RecordButton"].recording == 1 and self.RecordingNumber == self.PreviousRecordingNumber):
                # Find the probe's scan directory and make it if it doesn't exist
                sdir = FileManager.get_scans_dir(probe_id)
                ssdir = sdir + ft + FileManager.get_slash()
                FileManager.mkdir(sdir)
                FileManager.mkdir(ssdir)
                self.RecordingNumber = self.RecordingNumber + 1
                np.savetxt(ssdir + "im1_rec_" +str(self.RecordingNumber) + ".txt", im1.reshape(6220800), delimiter=',') # will have to undo this in data processing, original shape is (1080, 1920, 3)
                np.savetxt(ssdir + "im2_rec_" +str(self.RecordingNumber) + ".txt", im2.reshape(6220800), delimiter=',')
                np.savetxt(ssdir + "disp_map_rec_" +str(self.RecordingNumber) + ".txt", disp_map, delimiter=',')
                np.savetxt(ssdir + "stress_map_rec_" +str(self.RecordingNumber) + ".txt", stress_map, delimiter=',')
            elif (tm.tools["RecordButton"].recording == 1 and self.RecordingNumber != self.PreviousRecordingNumber):
                with open(ssdir + "im1_rec_" +str(self.RecordingNumber) + ".txt", "ab") as f:
                    f.write(b"\n")
                    np.savetxt(f, im1.reshape(6220800), delimiter=',')
                with open(ssdir + "im2_rec_" +str(self.RecordingNumber) + ".txt", "ab") as f:
                    f.write(b"\n")
                    np.savetxt(f, im2.reshape(6220800), delimiter=',')
                with open(ssdir + "disp_map_rec_" +str(self.RecordingNumber) + ".txt", "ab") as f:
                    f.write(b"\n")
                    np.savetxt(f, disp_map, delimiter=',')
                with open(ssdir + "stress_map_rec_" +str(self.RecordingNumber) + ".txt", "ab") as f:
                    f.write(b"\n")
                    np.savetxt(f, stress_map, delimiter=',')
            elif (tm.tools["RecordButton"].recording == 0 and self.RecordingNumber != self.PreviousRecordingNumber):
                self.PreviousRecordingNumber = self.RecordingNumber

            print("Display Time:\t{}".format(time.time() - start_time))

            print("Loop Time:\t{}\n\n".format(time.time() - start_time1))

            cu = disp_map.shape[0] // 2
            cv = disp_map.shape[1] // 2
            print("Center Location:\t(cu: {}, cv: {})".format(cu, cv))
            print("Disparity at Center:\t{}".format(disp_map[cu, cv]))

        plt.ioff()
        plt.show()

        # 4. Clean up resources
        self.camera.StopGrabbing()
        self.camera.Close()
        cv2.destroyAllWindows()


