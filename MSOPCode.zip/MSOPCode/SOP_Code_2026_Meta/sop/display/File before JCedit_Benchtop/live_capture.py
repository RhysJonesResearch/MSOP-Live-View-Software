import cv2
import time

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

from ximea import xiapi
from datetime import datetime
from ..logic import StereoImageProcessor
from .colormaps import ColorMaps
from ..utils import FileManager


def handle_close(event):
    """
    handle_close

    Description:
    Handles when the matplotlib plot closes.
    """

    # Close the program
    exit()


class LiveCapture:
    """
    LiveCapture

    Description:

    """

    def __init__(
        self,
        stereo_pro: StereoImageProcessor,
        conn: dict,
        res: tuple,
        disp_model: list,
        search_range: list,
        sub_spacing: int,
        window_size: int,
        estimated_offset: list,
        layer_thickness: float,
        speckle_height: float):
        """
        __init__

        Description:

        Inputs:

        Outputs:

        """

        # Check that the input types are correct
        if(not isinstance(stereo_pro, StereoImageProcessor)):
            err = "'stereo_pro' must be a StereoImageProcessor object."
            raise TypeError(err)

        if(not isinstance(conn, dict)):
            err = "'conn' should be a dict instance."
            raise TypeError(err)

        if(not isinstance(res, tuple)):
            err = "'res' should be a tuple instance."
            raise TypeError(err)

        if(not isinstance(disp_model, list)):
            err = "'disp_model' should be a list instance."
            raise TypeError(err)

        if(not isinstance(search_range, list)):
            err = "'search_range' should be a list."
            raise TypeError(err)

        if(not isinstance(sub_spacing, int)):
            err = "'sub_spacing' should be a int."
            raise TypeError(err)

        if(not isinstance(window_size, int)):
            err = "'window_size' should be a int."
            raise TypeError(err)

        if(not isinstance(estimated_offset, list)):
            err = "'estimated_offset' should be a list."
            raise TypeError(err)

        if(not isinstance(layer_thickness, float)):
            err = "'layer_thickness' should be a float."
            raise TypeError(err)

        if(not isinstance(speckle_height, float)):
            err = "'speckle_height' should be a float."
            raise TypeError(err)

        # Check the connection type
        if(conn["CONNECTION_TYPE"] == 1):
            # Initialise a video capture for both devices
            self.__left_cap = cv2.VideoCapture(int(conn["LEFT_PORT"]))
            self.__right_cap = cv2.VideoCapture(int(conn["RIGHT_PORT"]))
        elif(conn["CONNECTION_TYPE"] == 0):
            lip = "http://" + conn["LEFT_IP"] + ":" + conn["LEFT_PORT"]
            rip = "http://" + conn["RIGHT_IP"] + ":" + conn["RIGHT_PORT"]
            self.__left_cap = cv2.VideoCapture(lip)
            self.__right_cap = cv2.VideoCapture(rip)
        elif(conn["CONNECTION_TYPE"] == 2):
            # Open the benchtop cameras
            self.__left_cap = xiapi.Camera()
            self.__left_cap.open_device_by_SN(conn["LEFT_PORT"])
            self.__left_cap.set_param('auto_wb', True)
            self.__left_cap.set_exposure(150000)
            self.__right_cap = xiapi.Camera()
            self.__right_cap.open_device_by_SN(conn["RIGHT_PORT"])
            self.__right_cap.set_param('auto_wb', True)
            self.__right_cap.set_exposure(150000)

            # Set the colour scheme output and start the acquisition
            self.__left_cap.set_imgdataformat("XI_RGB24")
            self.__right_cap.set_imgdataformat("XI_RGB24")
            self.__left_cap.start_acquisition()
            self.__right_cap.start_acquisition()
        else:
            err = "Invalid connection type encountered."
            raise ValueError(err)

        # # Ben's probe
        # self.__left_cap = cv2.VideoCapture(1)
        # self.__right_cap = cv2.VideoCapture(0)

        # Aiden's probe
        # self.__right_cap = cv2.VideoCapture("http://192.168.0.1:8196/")
        # self.__left_cap = cv2.VideoCapture("http://192.168.0.2:8197/")

        # Change the resolution of the handheld systems
        if(conn["CONNECTION_TYPE"] != 2):
            self.__left_cap.set(3, res[0])
            self.__left_cap.set(4, res[1])
            self.__right_cap.set(3, res[0])
            self.__right_cap.set(4, res[1])

        # Save the stereo processor to a private field
        self.__stereo_pro = stereo_pro

        # Save the search range to a private field
        self.__search_range = search_range

        # Save sub_spacing and window_size to private fields
        self.__sub_spacing = sub_spacing
        self.__window_size = window_size

        # Save the estimated offset to a private field
        self.__estimated_offset = estimated_offset

        # Save the layer thickness and speckle hieght to a private fields
        self.__layer_thickness = layer_thickness
        self.__speckle_height = speckle_height
        self.__speckle_depth = self.__layer_thickness - self.__speckle_height

        # Define strain to stress parameters
        self.__AA = 0.022479
        self.__BB = 3.5987
        self.__CC = -0.021772
        self.__DD = 3.2488

        # Save the displacement model to private instance variables
        self.__disp_model = disp_model

        # Obtain the desired colour map
        self.__parula_cmap = ColorMaps.create_parula()
        self.__parula_cmap.set_bad(color = "black")

        # Save the connection type
        self.__connt = conn["CONNECTION_TYPE"]


    def display_live(self, probe_id: int = None):
        """
        display_live

        Description:

        """

        # Capture images and convert the colour accordingly
        im1 = None; im2 = None; image_show1 = None; image_show2 = None
        if(self.__connt != 2):
            ret1, im1 = self.__left_cap.read()
            im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)
            ret2, im2 = self.__right_cap.read()
            im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2RGB)
        else:
            # Read in images
            xi_im1 = xiapi.Image()
            xi_im2 = xiapi.Image()
            self.__left_cap.get_image(xi_im1)
            self.__right_cap.get_image(xi_im2)
            raw_im1 = list(xi_im1.get_image_data_raw())
            raw_im2 = list(xi_im2.get_image_data_raw())
            im1 = np.array(raw_im1).reshape((3680, 4896, 3)).astype(np.uint8)
            im2 = np.array(raw_im2).reshape((3680, 4896, 3)).astype(np.uint8)

        # Rectify the images
        lgray_rec, rgray_rec = self.__stereo_pro.rectify(
                                        self.__search_range, im1, im2)

        # Find the disparity image
        disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing,
                                    self.__window_size, self.__search_range)

        # Convert disparity to displacement
        dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1]

        # Convert displacement to strain
        strain_map = 1 - (dist_map * (1 + self.__speckle_height 
                        / self.__speckle_depth)) / (self.__layer_thickness)

        # Convert strain to stress (in MPa)
        stress_map = (self.__AA * np.exp(self.__BB * strain_map) +
                            self.__CC * np.exp(self.__DD * strain_map))

        # Benchtop system does not support live image display
        # if(self.__connt == 2):
        if(probe_id is None):
            err = "'probe_id' must be specified for the benchtop system."
            raise RuntimeError(err)

        if(self.__connt == 2):
            # Find the formatted time
            tt = datetime.today()
            ft = tt.strftime("%Y%m%d_%Hh%Mm%Ss")

            # Find the probe's scan directory and make it if it doesn't exist
            sdir = FileManager.get_scans_dir(probe_id)
            ssdir = sdir + ft + FileManager.get_slash()
            FileManager.mkdir(sdir)
            FileManager.mkdir(ssdir)

            # Draw the ROI on the images
            im1_rect, im2_rect = self.__stereo_pro.rectify(None, im1, im2)
            lroi, rroi = self.__stereo_pro.get_rois()
            ltl = (lroi["left_edge"], lroi["top_edge"])
            lbr = (lroi["right_edge"], lroi["bottom_edge"])
            rtl = (rroi["left_edge"], rroi["top_edge"])
            rbr = (rroi["right_edge"], rroi["bottom_edge"])
            im1_rect = cv2.rectangle(im1_rect, ltl, lbr, (0, 0, 255), 6)
            im2_rect = cv2.rectangle(im2_rect, rtl, rbr, (0, 0, 255), 6)

            # Save the images
            cv2.imwrite(ssdir + "left_img_{}.jpg".format(ft), im1)
            cv2.imwrite(ssdir + "right_img_{}.jpg".format(ft), im2)
            cv2.imwrite(ssdir + "left_rect_full_{}.jpg".format(ft), im1_rect)
            cv2.imwrite(ssdir + "right_rect_full_{}.jpg".format(ft), im2_rect)
            cv2.imwrite(ssdir + "left_rect_{}.jpg".format(ft), lgray_rec)
            cv2.imwrite(ssdir + "right_rect_{}.jpg".format(ft), rgray_rec)
            cv2.imwrite(ssdir + "disparity_map_{}.jpg".format(ft), disp_map)
            cv2.imwrite(ssdir + "displacement_map_{}.jpg".format(ft), dist_map)
            cv2.imwrite(ssdir + "strain_map_{}.jpg".format(ft), strain_map)
            cv2.imwrite(ssdir + "stress_map_{}.jpg".format(ft), stress_map)

            # Save the raw data
            np.save(ssdir + "left_img_{}.npy".format(ft), im1)
            np.save(ssdir + "right_img_{}.npy".format(ft), im2)
            np.save(ssdir + "left_rect_{}.npy".format(ft), lgray_rec)
            np.save(ssdir + "right_rect_{}.npy".format(ft), rgray_rec)
            np.save(ssdir + "disparity_map_{}.npy".format(ft), disp_map)
            np.save(ssdir + "displacement_map_{}.npy".format(ft), dist_map)
            np.save(ssdir + "strain_map_{}.npy".format(ft), strain_map)
            np.save(ssdir + "stress_map_{}.npy".format(ft), stress_map)

            # Process the disparity map
            du = np.mean(disp_map)
            dstd = np.std(disp_map)
            idx_x, idx_y = np.where(1.5*dstd < np.abs(disp_map-du))
            disp_map = disp_map.astype(np.float)
            disp_map[idx_x, idx_y] = np.nan

            # Display the disparity at the center pixel
            cu = disp_map.shape[0] // 2
            cv = disp_map.shape[1] // 2
            print("Center Location:\t(cu: {}, cv: {})".format(cu, cv))
            print("Disparity at Center:\t{}".format(disp_map[cu, cv]))

            # Show the disparity map
            plt.imshow(disp_map, cmap = self.__parula_cmap, clim = [du-1.5*dstd, du+1.5*dstd])
            plt.title("Disparity Map")
            plt.show()

            exit()

        # Initialise the figure window
        fig, axes = plt.subplots(3, 2)
        fig.canvas.mpl_connect("close_event", handle_close)
        plt.subplots_adjust(bottom = 0.05, top = 0.9, left = 0.05,
                                                            right = 0.96)
        fig.suptitle("SOP Live Display", fontsize = 14)

        # Initialize each axis
        axes[0, 0].set_title("Left Image", fontsize = 10)
        axes[0, 0].set_xticklabels([])
        axes[0, 0].set_yticklabels([])
        axes[0, 1].set_title("Right Image", fontsize = 10)
        axes[0, 1].set_xticklabels([])
        axes[0, 1].set_yticklabels([])
        axes[1, 0].set_title("Rectified Left Image", fontsize = 10)
        axes[1, 0].set_xticklabels([])
        axes[1, 0].set_yticklabels([])
        axes[1, 1].set_title("Rectified Right Image", fontsize = 10)
        axes[1, 1].set_xticklabels([])
        axes[1, 1].set_yticklabels([])
        axes[2, 0].set_title("Disparity Map", fontsize = 10)
        axes[2, 0].set_xticklabels([])
        axes[2, 0].set_yticklabels([])
        axes[2, 1].set_title("Stress Map", fontsize = 10)
        axes[2, 1].set_xticklabels([])
        axes[2, 1].set_yticklabels([])

        # Show the raw images
        image_show1 = axes[0, 0].imshow(im1)
        image_show2 = axes[0, 1].imshow(im2)

        # Find the ROIs
        left_ROI, right_ROI = self.__stereo_pro.get_rois()

        # Create the rectangles to draw onto the images
        ly = left_ROI['top_edge']
        lx = left_ROI['left_edge']
        ldy = left_ROI['bottom_edge'] - left_ROI['top_edge']
        ldx = left_ROI['right_edge'] - left_ROI['left_edge']
        rect1 = patches.Rectangle((lx, ly), ldx, ldy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')
        ry = right_ROI['top_edge']
        rx = right_ROI['left_edge']
        rdy = right_ROI['bottom_edge'] - right_ROI['top_edge']
        rdx = right_ROI['right_edge'] - right_ROI['left_edge']
        rect2 = patches.Rectangle((rx, ry), rdx, rdy, linewidth = 2,
                                    edgecolor = 'r', facecolor = 'none')

        # Add the rectangles to the image
        axes[0, 0].add_patch(rect1)
        axes[0, 1].add_patch(rect2)

        # Find the disparity map mean and standard deviation
        du = np.mean(disp_map)
        dstd = np.std(disp_map)

        # Cut out noise
        idx_x, idx_y = np.where(1.5*dstd < np.abs(disp_map-du))
        disp_map = disp_map.astype(np.float)
        disp_map[idx_x, idx_y] = np.nan

        # Display the rectified images
        image_show3 = axes[1, 0].imshow(lgray_rec, cmap = "gray")
        image_show4 = axes[1, 1].imshow(rgray_rec, cmap = "gray")
        image_show5 = axes[2, 0].imshow(disp_map, cmap = self.__parula_cmap,
                                            clim = [du-1.5*dstd, du+1.5*dstd])
        image_show6 = axes[2, 1].imshow(stress_map, cmap = self.__parula_cmap)
        fig.colorbar(image_show5, ax = axes[2, 0])
        fig.colorbar(image_show6, ax = axes[2, 1])

        # Interactive mode on
        plt.ion()

        # Take images and display them live
        while(True):
            start_time1 = time.time()

            # Capture image and convert its colour accordingly
            if(self.__connt != 2):
                ret1, im1 = self.__left_cap.read()
                im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2RGB)
                ret2, im2 = self.__right_cap.read()
                im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2RGB)
            else:
                # Read in images
                xi_im1 = xiapi.Image()
                xi_im2 = xiapi.Image()
                self.__left_cap.get_image(xi_im1)
                self.__right_cap.get_image(xi_im2)
                raw_im1 = list(xi_im1.get_image_data_raw())
                raw_im2 = list(xi_im2.get_image_data_raw())
                im1 = np.array(raw_im1).reshape((3680, 4896, 3)).astype(np.uint8)
                im2 = np.array(raw_im2).reshape((3680, 4896, 3)).astype(np.uint8)

            print("Capture Time:\t{}".format(time.time() - start_time1))

            start_time = time.time()

            # Rectify the images
            lgray_rec, rgray_rec = self.__stereo_pro.rectify(
                                                self.__search_range, im1, im2)

            print("Rectify Images:\t{}".format(time.time() - start_time))

            start_time = time.time()

            # Find the disparity image
            disp_map = self.__stereo_pro.get_disparity(self.__sub_spacing,
                                    self.__window_size, self.__search_range)

            # Convert disparity to displacement
            dist_map = self.__disp_model[0] * disp_map + self.__disp_model[1]

            # Convert displacement to strain
            strain_map = 1 - (dist_map * (1 + self.__speckle_height /
                            self.__speckle_depth)) / (self.__layer_thickness)

            # Convert strain to stress
            stress_map = (self.__AA * np.exp(self.__BB * strain_map) +
                                self.__CC * np.exp(self.__DD * strain_map))

            print("Disparity Mapping:\t{}".format(time.time() - start_time))

            # Find the disparity map mean and standard deviation
            du = np.mean(disp_map)
            dstd = np.std(disp_map)

            # Cut out noise
            idx_x, idx_y = np.where(1.5*dstd < np.abs(disp_map-du))
            disp_map = disp_map.astype(np.float)
            disp_map[idx_x, idx_y] = np.nan

            start_time = time.time()

            # Display all the images
            image_show5.set_clim([du-1.5*dstd, du+1.5*dstd])
            image_show1.set_data(im1)
            image_show2.set_data(im2)
            image_show3.set_data(lgray_rec)
            image_show4.set_data(rgray_rec)
            image_show5.set_data(disp_map)
            image_show6.set_data(stress_map)
            plt.pause(0.0000000001)

            print("Display Time:\t{}".format(time.time() - start_time))

            print("Loop Time:\t{}\n\n".format(time.time() - start_time1))

            cu = disp_map.shape[0] // 2
            cv = disp_map.shape[1] // 2
            print("Center Location:\t(cu: {}, cv: {})".format(cu, cv))
            print("Disparity at Center:\t{}".format(disp_map[cu, cv]))

        plt.ioff()
        plt.show()




