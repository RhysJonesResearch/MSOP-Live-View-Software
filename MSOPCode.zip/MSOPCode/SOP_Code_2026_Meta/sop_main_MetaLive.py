"""
Author: Rhys Jones
Date: Nov 2026
Company: BRITElab

******************************************************************************
PROGRAM DESCRIPTION:
Includes the code to run the SOP live processing.
******************************************************************************
"""

import json
import cv2
import logging

import numpy as np

from argparse import ArgumentParser
from sop.utils import FileManager, ConfigNotDefinedError
from sop.logic import StereoImageProcessor
from sop.display import LiveCaptureRec # edited __init__ file in display to make it use the Rhys_edit


if(__name__ == "__main__"):
    # Set the logging level
    logging.basicConfig(level = logging.INFO)

    # Handle command line arguments
    parser = ArgumentParser(description = "Calibrates a SOP system.")
    parser.add_argument("--probe_id", type = int, default = 2026 ,
                    help = "Specifies the ID of the probe to run on.")
    parser.add_argument("--sub_spacing", type = int, default = 1,
                    help = "Sub-spacing used in the disparity algorithm.")
    parser.add_argument("--window_size", type = int, default = 15,
                    help = "Defines the size of the window used in the"\
                            " disparity algorithm.")
    parser.add_argument("--layer_thickness", type = float, default = 4.5,
                    help = "The total thickness of the compliant layer.")
    parser.add_argument("--speckle_height", type = float, default = 0.05,
                    help = "The height of the speckles from the bottom of"
                            " the compliant layer.")
    args = parser.parse_args()

    # Check that the input types are valid
    if(not isinstance(args.probe_id, int)):
        err = "'probe_id' should be an int instance."
        raise TypeError(err)

    if(not isinstance(args.sub_spacing, int)):
        err = "'sub_spacing' should be an int instance."
        raise TypeError(err)

    if(not isinstance(args.window_size, int)):
        err = "'window_size' should be an int instance."
        raise TypeError(err)

    # Check that the input values are valid
    if(args.probe_id < 0):
        err = "'probe_id' should be greater than or equal to zero."
        raise ValueError(err)

    # Find the config file and read it in
    cfg_file = FileManager.get_probe_dir(args.probe_id) + "Config.json"
    try:
        with open(cfg_file, "r") as fp:
            cfg = json.load(fp)
    except FileNotFoundError:
        err = "The configuration file for this probe was not defined."
        raise ConfigNotDefinedError(err)
    except Exception as excp:
        print(str(excp))
        exit()

    # Extract the parameters of the system from the config file
    calib = cfg["CALIBRATION_PARAMETERS"]
    cmatL = np.array(calib["cmatrixL"])
    dcoefsL = np.array(calib["dcoefsL"])
    cmatR = np.array(calib["cmatrixR"])
    dcoefsR = np.array(calib["dcoefsR"])
    R_L = np.array(calib["R_L"])
    P_L = np.array(calib["P_L"])
    R_R = np.array(calib["R_R"])
    P_R = np.array(calib["P_R"])
    res = tuple(cfg["RESOLUTION"])
    offset = cfg["OFFSET_VALUES"]
    srange = cfg["SEARCH_RANGE"]
    conn = cfg["CONNECTION_DETAILS"]
    disp_mod = cfg["DISPLACEMENT_MODEL"]
    roi = cfg["ROI"]

    # Create a stereo image processor instance
    sp = StereoImageProcessor(cfg)

    # Initialise a LiveCatpure instance
    cap = LiveCaptureRec(sp, conn, res, disp_mod, srange,
                        args.sub_spacing, args.window_size,
                        offset, args.layer_thickness, args.speckle_height)

    # Start the live display
    cap.display_live(args.probe_id)
