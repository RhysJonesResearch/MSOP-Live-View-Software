"""
Author: Rhys Jones
Date: Nov 2026
Company: BRITElab

******************************************************************************
PROGRAM DESCRIPTION:
******************************************************************************
"""

import cv2

import numpy as np
from sop.utils import FileManager
from pypylon import pylon

#from ximea import xiapi


def take_picture():
    """
    take_picture

    Description:
    Takes a picture from the left and right camera of a probe.
    """
    
    probe_id = 2026

    # 1. Connect to the first available Basler camera
    camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())
    camera.Open()
    # Optional: Print camera model to verify connection
    print("Connected to:", camera.GetDeviceInfo().GetModelName())
    # 2. Configure the image format converter for OpenCV (BGR)
    converter = pylon.ImageFormatConverter()
    converter.OutputPixelFormat = pylon.PixelType_BGR8packed
    converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned
    # 3. settings
    camera.ExposureAuto.Value = "Off"
    camera.ExposureTime.Value = 30000.0  # In microseconds (10,000 us = 10 ms)
    camera.GainAuto.Value = "Off"
    camera.Gain.Value = 5.0  # In dB
    camera.Gamma.Value = 1.5

    # --- 4. Resolution / Region of Interest (ROI) ---
    # Must be set BEFORE StartGrabbing()
    camera.OffsetX.Value = 0
    camera.OffsetY.Value = 0
    camera.Width.Value = 3304 # needs to be divisble by 8
    camera.Height.Value = 1300
    camera.OffsetX.Value = 250
    camera.OffsetY.Value = 290
    
    # 4. Start grabbing frames (LatestImageOnly prevents lag/buffer buildup)
    camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
        
        
    for im_num in range(0,3):
        print("Press q to capture image (CTRL-C to quit): "+"{:0>{}}".format(im_num, 2))
        while(True):
            try:
                # Wait up to 5000 ms for a frame
                grabResult = camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)
                if grabResult.GrabSucceeded():
                    # Convert to OpenCV BGR NumPy array
                    image = converter.Convert(grabResult)
                    img = image.GetArray()
                    #img = img[:, :, 1] # take green channel only
                    # Resize for display if 4K (3840x2160) is too large for your screen
                    #display_img = cv2.resize(img, (1280, 720))
                    display_img = cv2.resize(img, (int(camera.Width.Value/4), int(camera.Height.Value/4)))
                grabResult.Release()
            except:
                print("CameraAcquisistionError")
            cv2.imshow('im', display_img)
            if cv2.waitKey(1) & 0xFF == ord('q'): 
                break
                
            
        res = [int(camera.Width.Value/8), int(camera.Height.Value/4)] # set res
        im1 = display_img[:,0:int(res[0])]
        im2 = display_img[:,int(res[0]):int(res[0]*2)]

        #cv2.imwrite(FileManager.get_left_dir(probe_id)+"Both.jpg", im)
        cv2.imwrite(FileManager.get_left_dir(probe_id)+"Left_"+"{:0>{}}".format(im_num, 2)+".jpg", im1)
        cv2.imwrite(FileManager.get_right_dir(probe_id)+"Right_"+"{:0>{}}".format(im_num, 2)+".jpg", im2)
        
        
    
    camera.StopGrabbing()
    camera.Close()
    cv2.destroyAllWindows()

    # ********************************************************************** #


if(__name__ == "__main__"):
	# Take pictures from the two cameras
	take_picture()